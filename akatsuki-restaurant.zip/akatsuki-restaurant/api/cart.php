<?php
/**
 * Cart API
 * Handle cart operations
 */

require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
initSession();

header('Content-Type: application/json; charset=utf-8');

// Get request data
$requestMethod = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

$db = getDB();

try {
    if ($requestMethod === 'POST') {
        handlePost($db, $input);
    } elseif ($requestMethod === 'GET') {
        handleGet($db);
    } else {
        jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
    }
} catch (Exception $e) {
    jsonResponse(['success' => false, 'message' => $e->getMessage()], 500);
}

/**
 * Handle GET requests
 */
function handleGet($db) {
    $cart = $_SESSION['cart'] ?? [];
    $cartItems = [];
    $total = 0;
    
    foreach ($cart as $index => $item) {
        $stmt = $db->prepare("
            SELECT m.*, c.name as category_name 
            FROM menu_items m 
            JOIN categories c ON m.category_id = c.category_id 
            WHERE m.menu_id = ?
        ");
        $stmt->execute([$item['menu_id']]);
        $menu = $stmt->fetch();
        
        if ($menu) {
            $subtotal = $menu['price'] * $item['quantity'];
            $total += $subtotal;
            
            $cartItems[] = [
                'index' => $index,
                'menu_id' => $item['menu_id'],
                'name_th' => $menu['name_th'],
                'category_name' => $menu['category_name'],
                'price' => $menu['price'],
                'quantity' => $item['quantity'],
                'special_request' => $item['special_request'] ?? '',
                'subtotal' => $subtotal,
                'image_url' => $menu['image_url']
            ];
        }
    }
    
    jsonResponse([
        'success' => true,
        'data' => [
            'items' => $cartItems,
            'total' => $total,
            'count' => count($cartItems)
        ]
    ]);
}

/**
 * Handle POST requests
 */
function handlePost($db, $input) {
    $action = $input['action'] ?? '';
    
    switch ($action) {
        case 'add':
            addToCart($db, $input);
            break;
            
        case 'update':
            updateCart($input);
            break;
            
        case 'remove':
            removeFromCart($input);
            break;
            
        case 'clear':
            clearCart();
            break;
            
        default:
            jsonResponse(['success' => false, 'message' => 'Invalid action'], 400);
    }
}

/**
 * Add item to cart
 */
function addToCart($db, $input) {
    $menuId = $input['menu_id'] ?? null;
    $quantity = $input['quantity'] ?? 1;
    $specialRequest = $input['special_request'] ?? '';

    // Check if table is selected
    if (!isset($_SESSION['table_id'])) {
        jsonResponse(['success' => false, 'message' => 'กรุณาเลือกโต๊ะก่อน'], 400);
    }
    
    if (!$menuId) {
        jsonResponse(['success' => false, 'message' => 'กรุณาระบุเมนู'], 400);
    }
    
    // Verify menu exists and is available
    $stmt = $db->prepare("SELECT * FROM menu_items WHERE menu_id = ? AND is_available = 1");
    $stmt->execute([$menuId]);
    $menu = $stmt->fetch();
    
    if (!$menu) {
        jsonResponse(['success' => false, 'message' => 'ไม่พบเมนูนี้หรือเมนูไม่พร้อมขาย'], 404);
    }
    
    // Initialize cart if not exists
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    // Check if item already in cart with same special request
    $found = false;
    foreach ($_SESSION['cart'] as &$item) {
        if ($item['menu_id'] == $menuId && $item['special_request'] == $specialRequest) {
            $item['quantity'] += $quantity;
            $found = true;
            break;
        }
    }
    
    // Add new item if not found
    if (!$found) {
        $_SESSION['cart'][] = [
            'menu_id' => $menuId,
            'quantity' => $quantity,
            'special_request' => $specialRequest
        ];
    }
    
    jsonResponse([
        'success' => true,
        'message' => 'เพิ่มลงตะกร้าสำเร็จ',
        'data' => [
            'cart_count' => array_sum(array_column($_SESSION['cart'], 'quantity'))
        ]
    ]);
}

/**
 * Update cart item quantity
 */
function updateCart($input) {
    $index = $input['index'] ?? null;
    $change = $input['change'] ?? 0;
    
    if ($index === null) {
        jsonResponse(['success' => false, 'message' => 'กรุณาระบุรายการ'], 400);
    }
    
    if (!isset($_SESSION['cart'][$index])) {
        jsonResponse(['success' => false, 'message' => 'ไม่พบรายการนี้'], 404);
    }
    
    // Update quantity
    $_SESSION['cart'][$index]['quantity'] += $change;
    
    // Remove if quantity is 0 or less
    if ($_SESSION['cart'][$index]['quantity'] <= 0) {
        unset($_SESSION['cart'][$index]);
        $_SESSION['cart'] = array_values($_SESSION['cart']); // Re-index
    }
    
    jsonResponse([
        'success' => true,
        'message' => 'อัปเดตตะกร้าสำเร็จ',
        'data' => [
            'cart_count' => isset($_SESSION['cart']) ? array_sum(array_column($_SESSION['cart'], 'quantity')) : 0
        ]
    ]);
}

/**
 * Remove item from cart
 */
function removeFromCart($input) {
    $index = $input['index'] ?? null;
    
    if ($index === null) {
        jsonResponse(['success' => false, 'message' => 'กรุณาระบุรายการ'], 400);
    }
    
    if (!isset($_SESSION['cart'][$index])) {
        jsonResponse(['success' => false, 'message' => 'ไม่พบรายการนี้'], 404);
    }
    
    // Remove item
    unset($_SESSION['cart'][$index]);
    $_SESSION['cart'] = array_values($_SESSION['cart']); // Re-index
    
    jsonResponse([
        'success' => true,
        'message' => 'ลบรายการสำเร็จ',
        'data' => [
            'cart_count' => isset($_SESSION['cart']) ? array_sum(array_column($_SESSION['cart'], 'quantity')) : 0
        ]
    ]);
}

/**
 * Clear entire cart
 */
function clearCart() {
    unset($_SESSION['cart']);
    
    jsonResponse([
        'success' => true,
        'message' => 'ล้างตะกร้าสำเร็จ',
        'data' => [
            'cart_count' => 0
        ]
    ]);
}
