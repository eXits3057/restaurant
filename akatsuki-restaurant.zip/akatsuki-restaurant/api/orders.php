<?php
/**
 * Orders API
 * Handle order operations
 */

require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
initSession();

header('Content-Type: application/json; charset=utf-8');

// Get request data
$requestMethod = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

$db = getDB();

try {
    switch ($requestMethod) {
        case 'GET':
            handleGet($db);
            break;
            
        case 'POST':
            handlePost($db, $input);
            break;
            
        case 'PUT':
            handlePut($db, $input);
            break;
            
        default:
            jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
    }
} catch (Exception $e) {
    jsonResponse(['success' => false, 'message' => $e->getMessage()], 500);
}

/**
 * Handle GET requests
 */
function handleGet($db) {
    $orderId = $_GET['order_id'] ?? null;
    
    if ($orderId) {
        // Get specific order
        getOrder($db, $orderId);
    } else {
        // Get all orders for current session
        getSessionOrders($db);
    }
}

/**
 * Handle POST requests
 */
function handlePost($db, $input) {
    $action = $input['action'] ?? '';
    
    switch ($action) {
        case 'create_order':
            createOrder($db);
            break;
            
        default:
            jsonResponse(['success' => false, 'message' => 'Invalid action'], 400);
    }
}

/**
 * Handle PUT requests
 */
function handlePut($db, $input) {
    $action = $input['action'] ?? '';
    
    switch ($action) {
        case 'update_status':
            updateOrderStatus($db, $input);
            break;
            
        case 'update_item_status':
            updateItemStatus($db, $input);
            break;
            
        default:
            jsonResponse(['success' => false, 'message' => 'Invalid action'], 400);
    }
}

/**
 * Get specific order
 */
function getOrder($db, $orderId) {
    // Get order details
    $stmt = $db->prepare("
        SELECT o.*, t.table_number, t.seats
        FROM orders o
        JOIN tables t ON o.table_id = t.table_id
        WHERE o.order_id = ?
    ");
    $stmt->execute([$orderId]);
    $order = $stmt->fetch();
    
    if (!$order) {
        jsonResponse(['success' => false, 'message' => 'ไม่พบออเดอร์นี้'], 404);
    }
    
    // Get order items
    $stmt = $db->prepare("
        SELECT oi.*, m.name_th, m.image_url, c.name as category_name
        FROM order_items oi
        JOIN menu_items m ON oi.menu_id = m.menu_id
        JOIN categories c ON m.category_id = c.category_id
        WHERE oi.order_id = ?
        ORDER BY oi.order_item_id
    ");
    $stmt->execute([$orderId]);
    $items = $stmt->fetchAll();
    
    $order['items'] = $items;
    
    jsonResponse([
        'success' => true,
        'data' => $order
    ]);
}

/**
 * Get all orders for current session
 */
function getSessionOrders($db) {
    $sessionId = $_SESSION['session_id'] ?? null;
    
    if (!$sessionId) {
        jsonResponse(['success' => false, 'message' => 'ไม่พบ session'], 400);
    }
    
    $stmt = $db->prepare("
        SELECT o.*, t.table_number
        FROM orders o
        JOIN tables t ON o.table_id = t.table_id
        WHERE o.session_id = ?
        ORDER BY o.order_date DESC
    ");
    $stmt->execute([$sessionId]);
    $orders = $stmt->fetchAll();
    
    jsonResponse([
        'success' => true,
        'data' => $orders
    ]);
}

/**
 * Create new order from cart
 */
function createOrder($db) {
    // Check if table is selected
    $tableId = $_SESSION['table_id'] ?? null;
    
    if (!$tableId) {
        jsonResponse(['success' => false, 'message' => 'กรุณาเลือกโต๊ะก่อน'], 400);
    }

    // Get table's current session
    $stmt = $db->prepare("SELECT current_session_id FROM tables WHERE table_id = ?");
    $stmt->execute([$tableId]);
    $result = $stmt->fetch();
    $sessionId = $result['current_session_id'];
    
    if (!$sessionId) {
        jsonResponse(['success' => false, 'message' => 'ไม่พบเซสชันที่เกี่ยวข้องกับโต๊ะนี้'], 400);
    }
    
    // Check if cart is empty
    $cart = $_SESSION['cart'] ?? [];
    if (empty($cart)) {
        jsonResponse(['success' => false, 'message' => 'ตะกร้าว่างเปล่า'], 400);
    }
    
    // Start transaction
    $db->beginTransaction();
    
    try {
        // Generate order number
        $orderNumber = generateOrderNumber();
        
        // Calculate total
        $total = 0;
        foreach ($cart as $item) {
            $stmt = $db->prepare("SELECT price, cost FROM menu_items WHERE menu_id = ?");
            $stmt->execute([$item['menu_id']]);
            $menu = $stmt->fetch();
            if ($menu) {
                $total += $menu['price'] * $item['quantity'];
            }
        }
        
        // Create order
        $stmt = $db->prepare("
            INSERT INTO orders (session_id, table_id, order_number, order_date, total_price, status) 
            VALUES (?, ?, ?, NOW(), ?, 'pending')
        ");
        $stmt->execute([$sessionId, $tableId, $orderNumber, $total]);
        $orderId = $db->lastInsertId();
        
        // Create order items
        foreach ($cart as $item) {
            $stmt = $db->prepare("SELECT price, cost FROM menu_items WHERE menu_id = ?");
            $stmt->execute([$item['menu_id']]);
            $menu = $stmt->fetch();
            
            if ($menu) {
                $stmt = $db->prepare("
                    INSERT INTO order_items (order_id, menu_id, quantity, price, cost, special_request, status) 
                    VALUES (?, ?, ?, ?, ?, ?, 'pending')
                ");
                $stmt->execute([
                    $orderId,
                    $item['menu_id'],
                    $item['quantity'],
                    $menu['price'],
                    $menu['cost'],
                    $item['special_request'] ?? ''
                ]);
            }
        }
        
        // Update menu popularity
        foreach ($cart as $item) {
            $stmt = $db->prepare("
                UPDATE menu_items 
                SET popularity_score = popularity_score + ? 
                WHERE menu_id = ?
            ");
            $stmt->execute([$item['quantity'], $item['menu_id']]);
        }
        
        // Clear cart
        unset($_SESSION['cart']);
        
        $db->commit();
        
        jsonResponse([
            'success' => true,
            'message' => 'สร้างออเดอร์สำเร็จ',
            'data' => [
                'order_id' => $orderId,
                'order_number' => $orderNumber,
                'total_price' => $total
            ]
        ]);
    } catch (Exception $e) {
        $db->rollBack();
        jsonResponse(['success' => false, 'message' => 'เกิดข้อผิดพลาด: ' . $e->getMessage()], 500);
    }
}

/**
 * Update order status
 */
function updateOrderStatus($db, $input) {
    $orderId = $input['order_id'] ?? null;
    $status = $input['status'] ?? null;
    
    if (!$orderId || !$status) {
        jsonResponse(['success' => false, 'message' => 'กรุณาระบุข้อมูลให้ครบถ้วน'], 400);
    }
    
    // Validate status
    $validStatuses = ['pending', 'confirmed', 'cooking', 'ready', 'served', 'completed', 'cancelled'];
    if (!in_array($status, $validStatuses)) {
        jsonResponse(['success' => false, 'message' => 'สถานะไม่ถูกต้อง'], 400);
    }
    
    try {
        // Update order status
        $stmt = $db->prepare("UPDATE orders SET status = ? WHERE order_id = ?");
        $stmt->execute([$status, $orderId]);
        
        // Update timestamp based on status
        if ($status === 'confirmed') {
            $stmt = $db->prepare("UPDATE orders SET confirmed_at = NOW() WHERE order_id = ?");
            $stmt->execute([$orderId]);
        } elseif ($status === 'completed') {
            $stmt = $db->prepare("UPDATE orders SET completed_at = NOW() WHERE order_id = ?");
            $stmt->execute([$orderId]);
        }
        
        // Update all order items status to match order status (except cancelled/rejected items)
        if ($status !== 'cancelled') {
            $stmt = $db->prepare("
                UPDATE order_items 
                SET status = ? 
                WHERE order_id = ? AND status NOT IN ('cancelled', 'rejected')
            ");
            $stmt->execute([$status, $orderId]);
        }

            // If order moved to 'ready' or 'served', mark any kitchen_queue entry for this order as processed
            if (in_array($status, ['ready', 'served'], true)) {
                try {
                    // Ensure kitchen_queue exists (migration-safe)
                    $db->exec("CREATE TABLE IF NOT EXISTS kitchen_queue (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        order_id INT NOT NULL,
                        order_number VARCHAR(50),
                        table_number VARCHAR(20),
                        total_items INT DEFAULT 0,
                        total_price DECIMAL(10,2) DEFAULT 0.00,
                        order_date DATETIME NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        processed TINYINT(1) DEFAULT 0,
                        UNIQUE KEY uq_order (order_id)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

                    $upd = $db->prepare("UPDATE kitchen_queue SET processed = 1 WHERE order_id = ?");
                    $upd->execute([$orderId]);
                } catch (Exception $e) {
                    // Non-fatal: if kitchen_queue doesn't exist or update fails, continue without blocking the main flow
                    error_log('kitchen_queue update failed: ' . $e->getMessage());
                }
            }
        
        jsonResponse([
            'success' => true,
            'message' => 'อัปเดตสถานะสำเร็จ'
        ]);
    } catch (Exception $e) {
        jsonResponse(['success' => false, 'message' => 'เกิดข้อผิดพลาด: ' . $e->getMessage()], 500);
    }
}

/**
 * Update order item status
 */
function updateItemStatus($db, $input) {
    $itemId = $input['item_id'] ?? null;
    $status = $input['status'] ?? null;
    
    if (!$itemId || !$status) {
        jsonResponse(['success' => false, 'message' => 'กรุณาระบุข้อมูลให้ครบถ้วน'], 400);
    }
    
    // Validate status
    $validStatuses = ['pending', 'confirmed', 'cooking', 'ready', 'served', 'rejected'];
    if (!in_array($status, $validStatuses)) {
        jsonResponse(['success' => false, 'message' => 'สถานะไม่ถูกต้อง'], 400);
    }
    
    try {
        // Update item status
        $stmt = $db->prepare("UPDATE order_items SET status = ? WHERE order_item_id = ?");
        $stmt->execute([$status, $itemId]);
        
        // Update timestamp based on status
        if ($status === 'cooking') {
            $stmt = $db->prepare("UPDATE order_items SET started_cooking_at = NOW() WHERE order_item_id = ?");
            $stmt->execute([$itemId]);
        } elseif ($status === 'ready') {
            $stmt = $db->prepare("UPDATE order_items SET ready_at = NOW() WHERE order_item_id = ?");
            $stmt->execute([$itemId]);
        }
        
        // Check if all items in order have same status and update order status
        $stmt = $db->prepare("SELECT order_id FROM order_items WHERE order_item_id = ?");
        $stmt->execute([$itemId]);
        $item = $stmt->fetch();
        
        if ($item) {
            $stmt = $db->prepare("
                SELECT DISTINCT status 
                FROM order_items 
                WHERE order_id = ? AND status NOT IN ('cancelled', 'rejected')
            ");
            $stmt->execute([$item['order_id']]);
            $statuses = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            // If all items have the same status, update order status
            if (count($statuses) === 1) {
                $stmt = $db->prepare("UPDATE orders SET status = ? WHERE order_id = ?");
                $stmt->execute([$statuses[0], $item['order_id']]);
            }
        }
        
        jsonResponse([
            'success' => true,
            'message' => 'อัปเดตสถานะสำเร็จ'
        ]);
    } catch (Exception $e) {
        jsonResponse(['success' => false, 'message' => 'เกิดข้อผิดพลาด: ' . $e->getMessage()], 500);
    }
}
