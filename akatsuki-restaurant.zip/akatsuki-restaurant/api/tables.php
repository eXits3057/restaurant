<?php
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
header('Content-Type: application/json');

$db = getDB();
$method = $_SERVER['REQUEST_METHOD'];

try {
    if ($method === 'GET') {
        $action = $_GET['action'] ?? 'list';
        
        if ($action === 'list') {
            // Get all tables
            $stmt = $db->query("SELECT * FROM tables ORDER BY table_number");
            $tables = $stmt->fetchAll();
            
            jsonResponse(['success' => true, 'data' => $tables]);
        }
        
        if ($action === 'get') {
            $tableId = $_GET['id'] ?? 0;
            $stmt = $db->prepare("SELECT * FROM tables WHERE table_id = ?");
            $stmt->execute([$tableId]);
            $table = $stmt->fetch();
            
            if ($table) {
                jsonResponse(['success' => true, 'data' => $table]);
            } else {
                jsonResponse(['success' => false, 'message' => 'ไม่พบโต๊ะ'], 404);
            }
        }
    }
    
    if ($method === 'POST') {
        $data = json_decode(file_get_contents('php://input'), true);
        $action = $data['action'] ?? '';
        
        if ($action === 'start_session') {
            $tableId = $data['table_id'] ?? 0;
            
            // Check if table is available
            $stmt = $db->prepare("SELECT * FROM tables WHERE table_id = ? AND status = 'available'");
            $stmt->execute([$tableId]);
            $table = $stmt->fetch();
            
            if (!$table) {
                jsonResponse(['success' => false, 'message' => 'โต๊ะไม่ว่างหรือไม่พบ'], 400);
            }
            
            $db->beginTransaction();
            
            try {
                // Create session
                $stmt = $db->prepare("INSERT INTO sessions (table_id, start_time) VALUES (?, NOW())");
                $stmt->execute([$tableId]);
                $sessionId = $db->lastInsertId();
                
                // Update table status
                $stmt = $db->prepare("UPDATE tables SET status = 'occupied', current_session_id = ? WHERE table_id = ?");
                $stmt->execute([$sessionId, $tableId]);
                
                $db->commit();
                
                jsonResponse([
                    'success' => true,
                    'message' => 'เริ่มใช้งานโต๊ะสำเร็จ',
                    'session_id' => $sessionId
                ]);
            } catch (Exception $e) {
                $db->rollBack();
                throw $e;
            }
        }
    }
    
    if ($method === 'PUT') {
        $data = json_decode(file_get_contents('php://input'), true);
        $action = $data['action'] ?? '';
        
        if ($action === 'update_status') {
            $tableId = $data['table_id'] ?? 0;
            $status = $data['status'] ?? '';
            
            $stmt = $db->prepare("UPDATE tables SET status = ? WHERE table_id = ?");
            $stmt->execute([$status, $tableId]);
            
            jsonResponse(['success' => true, 'message' => 'อัพเดทสถานะสำเร็จ']);
        }
        
        if ($action === 'end_session') {
            $tableId = $data['table_id'] ?? 0;
            
            // Get current session
            $stmt = $db->prepare("SELECT current_session_id FROM tables WHERE table_id = ?");
            $stmt->execute([$tableId]);
            $result = $stmt->fetch();
            $sessionId = $result['current_session_id'];
            
            if ($sessionId) {
                $db->beginTransaction();
                
                try {
                    // End session
                    $stmt = $db->prepare("UPDATE sessions SET end_time = NOW() WHERE session_id = ?");
                    $stmt->execute([$sessionId]);
                    
                    // Update table
                    $stmt = $db->prepare("UPDATE tables SET status = 'cleaning', current_session_id = NULL WHERE table_id = ?");
                    $stmt->execute([$tableId]);
                    
                    $db->commit();
                    
                    jsonResponse(['success' => true, 'message' => 'ปิดโต๊ะสำเร็จ']);
                } catch (Exception $e) {
                    $db->rollBack();
                    throw $e;
                }
            }
        }
    }
    
} catch (Exception $e) {
    jsonResponse([
        'success' => false,
        'message' => 'เกิดข้อผิดพลาด: ' . $e->getMessage()
    ], 500);
}
?>
