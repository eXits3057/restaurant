<?php
require_once '../config/database.php';

try {
    // Create connection without selecting database
    $conn = new PDO("mysql:host=" . DB_HOST, DB_USER, DB_PASS);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Create database if not exists
    $sql = "CREATE DATABASE IF NOT EXISTS " . DB_NAME . " CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
    $conn->exec($sql);
    echo "✅ สร้างฐานข้อมูลสำเร็จ<br>";
    
    // Select database
    $conn->exec("USE " . DB_NAME);
    
    // SQL statements to create tables
    $tables = [
        // Users table
        "CREATE TABLE IF NOT EXISTS users (
            user_id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            role ENUM('staff', 'chef', 'admin') NOT NULL,
            full_name VARCHAR(100) NOT NULL,
            phone VARCHAR(20),
            email VARCHAR(100),
            status ENUM('active', 'inactive') DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_username (username),
            INDEX idx_role (role),
            INDEX idx_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // Tables (Restaurant Tables)
        "CREATE TABLE IF NOT EXISTS tables (
            table_id INT AUTO_INCREMENT PRIMARY KEY,
            table_number VARCHAR(10) UNIQUE NOT NULL,
            seats INT NOT NULL DEFAULT 4,
            status ENUM('available', 'occupied', 'cleaning') DEFAULT 'available',
            current_session_id INT DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_status (status),
            INDEX idx_table_number (table_number)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // Categories
        "CREATE TABLE IF NOT EXISTS categories (
            category_id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            name_en VARCHAR(100),
            description TEXT,
            display_order INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_display_order (display_order)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // Menu Items
        "CREATE TABLE IF NOT EXISTS menu_items (
            menu_id INT AUTO_INCREMENT PRIMARY KEY,
            category_id INT NOT NULL,
            name_th VARCHAR(150) NOT NULL,
            name_en VARCHAR(150),
            description TEXT,
            price DECIMAL(10, 2) NOT NULL,
            cost DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
            image_url VARCHAR(255),
            is_available BOOLEAN DEFAULT TRUE,
            popularity_score INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE CASCADE,
            INDEX idx_category (category_id),
            INDEX idx_available (is_available),
            INDEX idx_popularity (popularity_score)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // Sessions
        "CREATE TABLE IF NOT EXISTS sessions (
            session_id INT AUTO_INCREMENT PRIMARY KEY,
            table_id INT NOT NULL,
            start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            end_time TIMESTAMP NULL,
            total_amount DECIMAL(10, 2) DEFAULT 0.00,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (table_id) REFERENCES tables(table_id) ON DELETE CASCADE,
            INDEX idx_table (table_id),
            INDEX idx_start_time (start_time)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // Orders
        "CREATE TABLE IF NOT EXISTS orders (
            order_id INT AUTO_INCREMENT PRIMARY KEY,
            session_id INT NOT NULL,
            table_id INT NOT NULL,
            order_number VARCHAR(20) UNIQUE NOT NULL,
            order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            total_price DECIMAL(10, 2) DEFAULT 0.00,
            status ENUM('pending', 'confirmed', 'cooking', 'ready', 'served', 'completed', 'cancelled') DEFAULT 'pending',
            payment_status ENUM('unpaid', 'paid') DEFAULT 'unpaid',
            payment_method ENUM('cash', 'card', 'qr_code') DEFAULT NULL,
            cash_received DECIMAL(10, 2) DEFAULT NULL,
            change_amount DECIMAL(10, 2) DEFAULT NULL,
            staff_id INT DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            confirmed_at TIMESTAMP NULL,
            completed_at TIMESTAMP NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (session_id) REFERENCES sessions(session_id) ON DELETE CASCADE,
            FOREIGN KEY (table_id) REFERENCES tables(table_id) ON DELETE CASCADE,
            FOREIGN KEY (staff_id) REFERENCES users(user_id) ON DELETE SET NULL,
            INDEX idx_session (session_id),
            INDEX idx_table (table_id),
            INDEX idx_status (status),
            INDEX idx_payment_status (payment_status),
            INDEX idx_order_date (order_date)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        // Order Items
        "CREATE TABLE IF NOT EXISTS order_items (
            order_item_id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT NOT NULL,
            menu_id INT NOT NULL,
            quantity INT NOT NULL DEFAULT 1,
            price DECIMAL(10, 2) NOT NULL,
            cost DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
            special_request TEXT,
            status ENUM('pending', 'confirmed', 'cooking', 'ready', 'served', 'rejected') DEFAULT 'pending',
            reject_reason VARCHAR(255),
            started_cooking_at TIMESTAMP NULL,
            ready_at TIMESTAMP NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
            FOREIGN KEY (menu_id) REFERENCES menu_items(menu_id) ON DELETE CASCADE,
            INDEX idx_order (order_id),
            INDEX idx_menu (menu_id),
            INDEX idx_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        ,
        // Kitchen queue for ready-order notifications
        "CREATE TABLE IF NOT EXISTS kitchen_queue (
            id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT NOT NULL,
            order_number VARCHAR(50),
            table_number VARCHAR(20),
            total_items INT DEFAULT 0,
            total_price DECIMAL(10,2) DEFAULT 0.00,
            order_date DATETIME NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            processed TINYINT(1) DEFAULT 0,
            UNIQUE KEY uq_order (order_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    ];

    // Create tables
    foreach ($tables as $sql) {
        $conn->exec($sql);
    }
    echo "✅ สร้างตารางทั้งหมดสำเร็จ<br>";

    // Insert sample data
    $sampleData = [
        // Insert default users (password: admin123)
        "INSERT INTO users (username, password, role, full_name, phone, email) VALUES
        ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'ผู้ดูแลระบบ', '0812345678', 'admin@akatsuki.com'),
        ('staff01', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'staff', 'พนักงาน 1', '0823456789', 'staff01@akatsuki.com'),
        ('chef01', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'chef', 'พ่อครัว 1', '0834567890', 'chef01@akatsuki.com')",

        // Insert tables
        "INSERT INTO tables (table_number, seats, status) VALUES
        ('T01', 2, 'available'),
        ('T02', 2, 'available'),
        ('T03', 4, 'available'),
        ('T04', 4, 'available'),
        ('T05', 4, 'available'),
        ('T06', 6, 'available'),
        ('T07', 6, 'available'),
        ('T08', 8, 'available')",

        // Insert categories
        "INSERT INTO categories (name, name_en, description, display_order) VALUES
        ('ซูชิ', 'Sushi', 'ซูชิสดใหม่หลากหลายชนิด', 1),
        ('ราเมง', 'Ramen', 'ราเมงน้ำซุปเข้มข้นรสชาติต้นตำรับ', 2),
        ('เมนูข้าว', 'Rice Dishes', 'อาหารจานข้าวหลากหลาย', 3),
        ('เครื่องเคียง', 'Side Dishes', 'เครื่องเคียงและของทานเล่น', 4),
        ('เครื่องดื่ม', 'Beverages', 'เครื่องดื่มสดชื่น', 5),
        ('ของหวาน', 'Desserts', 'ของหวานแบบญี่ปุ่น', 6)",

        // Insert menu items
        "INSERT INTO menu_items (category_id, name_th, name_en, description, price, cost, image_url, popularity_score) VALUES
        (1, 'ซูชิแซลมอน', 'Salmon Sushi', 'ซูชิแซลมอนสดใหม่ 2 ชิ้น', 80.00, 35.00, 'salmon_sushi.jpg', 150),
        (1, 'ซูชิมากุโร่', 'Maguro Sushi', 'ซูชิปลาทูน่าเนื้อแดง 2 ชิ้น', 120.00, 50.00, 'maguro_sushi.jpg', 120),
        (1, 'ซูชิไข่หวาน', 'Tamago Sushi', 'ซูชิไข่หวานแบบญี่ปุ่น 2 ชิ้น', 60.00, 20.00, 'tamago_sushi.jpg', 90),
        (1, 'แคลิฟอร์เนียโรล', 'California Roll', 'ซูชิม้วนแคลิฟอร์เนีย 8 ชิ้น', 150.00, 60.00, 'california_roll.jpg', 180),
        (2, 'ราเมงโชยุ', 'Shoyu Ramen', 'ราเมงน้ำซุปซีอิ๊วรสดั้งเดิม', 180.00, 70.00, 'shoyu_ramen.jpg', 200),
        (2, 'ราเมงมิโซะ', 'Miso Ramen', 'ราเมงน้ำซุปมิโซะรสเข้มข้น', 190.00, 75.00, 'miso_ramen.jpg', 180),
        (3, 'ข้าวหน้าปลาไหลย่าง', 'Unagi Don', 'ข้าวหน้าปลาไหลย่างซอสเทอริยากิ', 250.00, 100.00, 'unagi_don.jpg', 170),
        (4, 'เกี้ยวซ่า', 'Gyoza', 'เกี้ยวซ่าทอดกรอบ 6 ชิ้น', 90.00, 35.00, 'gyoza.jpg', 160),
        (5, 'ชาเขียวเย็น', 'Iced Green Tea', 'ชาเขียวเย็นสดชื่น', 50.00, 15.00, 'green_tea.jpg', 180),
        (6, 'โมจิไอศกรีม', 'Mochi Ice Cream', 'โมจิไอศกรีม 3 ชิ้น', 80.00, 30.00, 'mochi.jpg', 170)"
    ];

    // Insert sample data
    foreach ($sampleData as $sql) {
        try {
            $conn->exec($sql);
        } catch (PDOException $e) {
            // Skip if data already exists
            continue;
        }
    }
    echo "✅ เพิ่มข้อมูลตัวอย่างสำเร็จ<br>";
    
    echo "<br>✨ ติดตั้งฐานข้อมูลสำเร็จ!<br>";
    echo "รายละเอียดบัญชีผู้ใช้:<br>";
    echo "- Admin: admin / admin123<br>";
    echo "- Staff: staff01 / admin123<br>";
    echo "- Chef: chef01 / admin123<br>";

} catch(PDOException $e) {
    die("❌ เกิดข้อผิดพลาด: " . $e->getMessage());
}
?>