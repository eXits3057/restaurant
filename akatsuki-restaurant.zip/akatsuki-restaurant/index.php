<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Akatsuki Restaurant - ร้านอาหารญี่ปุ่น</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <nav class="navbar">
            <div class="logo">
                <i class="fas fa-torii-gate logo-icon"></i>
                <span>Akatsuki Restaurant</span>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php" class="nav-link active">หน้าแรก</a></li>
                 <li><a href="staff/dashboard.php" class="nav-link">พนักงาน</a></li> 
            </ul>
        </nav>
    </header>

    <!-- Hero Section -->
    <section class="hero" style="background: linear-gradient(135deg, #E60012 0%, #C00010 100%); color: white; padding: 4rem 0; text-align: center;">
        <div class="container">
            <h1 style="font-size: 3rem; margin-bottom: 1rem;">ยินดีต้อนรับสู่ Akatsuki Restaurant</h1>
            <p style="font-size: 1.3rem; margin-bottom: 2rem;">ร้านอาหารญี่ปุ่นต้นตำรับ เสิร์ฟความสุขในทุกคำ</p>
            <a href="customer/select-table.php" class="btn btn-lg" style="background: white; color: #E60012; font-size: 1.2rem; padding: 1.2rem 3rem;">
                <i class="fas fa-utensils"></i> เริ่มสั่งอาหาร
            </a>
        </div>
    </section>

    <!-- Features Section -->
    <section class="section">
        <div class="container">
            <h2 class="section-title">ทำไมต้องเลือก Akatsuki?</h2>
            <div class="row" style="margin-top: 2rem;">
                <div class="col col-4 col-sm-12" style="margin-bottom: 2rem;">
                    <div class="card text-center">
                        <div class="card-body">
                            <i class="fas fa-fish" style="font-size: 3rem; color: #E60012; margin-bottom: 1rem;"></i>
                            <h3>วัตถุดิบสดใหม่</h3>
                            <p class="text-muted">นำเข้าจากญี่ปุ่นโดยตรง รับรองคุณภาพระดับพรีเมี่ยม</p>
                        </div>
                    </div>
                </div>
                <div class="col col-4 col-sm-12" style="margin-bottom: 2rem;">
                    <div class="card text-center">
                        <div class="card-body">
                            <i class="fas fa-users-cog" style="font-size: 3rem; color: #E60012; margin-bottom: 1rem;"></i>
                            <h3>เชฟมืออาชีพ</h3>
                            <p class="text-muted">ทีมเชฟชาวญี่ปุ่นและไทยที่ผ่านการฝึกฝนมาอย่างดี</p>
                        </div>
                    </div>
                </div>
                <div class="col col-4 col-sm-12" style="margin-bottom: 2rem;">
                    <div class="card text-center">
                        <div class="card-body">
                            <i class="fas fa-mobile-alt" style="font-size: 3rem; color: #E60012; margin-bottom: 1rem;"></i>
                            <h3>สั่งง่าย จ่ายสะดวก</h3>
                            <p class="text-muted">ระบบสั่งอาหารผ่านเว็บ รองรับหลายช่องทางชำระเงิน</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Menu Highlights -->
    <section class="section" style="background: #F8F9FA;">
        <div class="container">
            <h2 class="section-title">เมนูยอดนิยม</h2>
            <div class="row" style="margin-top: 2rem;">
                <div class="col col-3 col-sm-6" style="margin-bottom: 2rem;">
                    <div class="card">
                        <img src="assets/images/menu/placeholder-sushi.jpg" alt="Sushi" class="card-img" style="background: #e0e0e0;">
                        <div class="card-body">
                            <h4 class="card-title">ซูชิหลากหลาย</h4>
                            <p class="card-text">ซูชิสดใหม่จากทะเล ครบรสชาติในทุกคำ</p>
                            <p class="card-price">฿60 - ฿150</p>
                        </div>
                    </div>
                </div>
                <div class="col col-3 col-sm-6" style="margin-bottom: 2rem;">
                    <div class="card">
                        <img src="assets/images/menu/placeholder-ramen.jpg" alt="Ramen" class="card-img" style="background: #e0e0e0;">
                        <div class="card-body">
                            <h4 class="card-title">ราเมงแท้</h4>
                            <p class="card-text">น้ำซุปเข้มข้น เส้นเหนียวนุ่ม รสชาติต้นตำรับ</p>
                            <p class="card-price">฿180 - ฿200</p>
                        </div>
                    </div>
                </div>
                <div class="col col-3 col-sm-6" style="margin-bottom: 2rem;">
                    <div class="card">
                        <img src="assets/images/menu/placeholder-rice.jpg" alt="Rice Bowl" class="card-img" style="background: #e0e0e0;">
                        <div class="card-body">
                            <h4 class="card-title">ข้าวหน้าหลากหลาย</h4>
                            <p class="card-text">ข้าวญี่ปุ่นร้อนๆ กับเครื่องหน้าชั้นดี</p>
                            <p class="card-price">฿180 - ฿280</p>
                        </div>
                    </div>
                </div>
                <div class="col col-3 col-sm-6" style="margin-bottom: 2rem;">
                    <div class="card">
                        <img src="assets/images/menu/placeholder-side.jpg" alt="Side Dishes" class="card-img" style="background: #e0e0e0;">
                        <div class="card-body">
                            <h4 class="card-title">เครื่องเคียง</h4>
                            <p class="card-text">เกี้ยวซ่า ทาโกะยากิ และอื่นๆ อีกมากมาย</p>
                            <p class="card-price">฿60 - ฿150</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-center" style="margin-top: 2rem;">
                <a href="customer/select-table.php" class="btn btn-primary btn-lg">
                    <i class="fas fa-arrow-right"></i> ดูเมนูทั้งหมด
                </a>
            </div>
        </div>
    </section>

    <!-- How It Works -->
    <section class="section">
        <div class="container">
            <h2 class="section-title">วิธีการสั่งอาหาร</h2>
            <div class="row" style="margin-top: 3rem;">
                <div class="col col-3 col-sm-6 text-center" style="margin-bottom: 2rem;">
                    <div style="width: 80px; height: 80px; background: #E60012; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem; color: white; font-size: 2rem; font-weight: 700;">1</div>
                    <h4>เลือกโต๊ะ</h4>
                    <p class="text-muted">คลิกเลือกโต๊ะที่ว่าง หรือสแกน QR Code บนโต๊ะ</p>
                </div>
                <div class="col col-3 col-sm-6 text-center" style="margin-bottom: 2rem;">
                    <div style="width: 80px; height: 80px; background: #E60012; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem; color: white; font-size: 2rem; font-weight: 700;">2</div>
                    <h4>เลือกเมนู</h4>
                    <p class="text-muted">เลือกเมนูที่ชอบ ใส่ตะกร้า และยืนยันคำสั่งซื้อ</p>
                </div>
                <div class="col col-3 col-sm-6 text-center" style="margin-bottom: 2rem;">
                    <div style="width: 80px; height: 80px; background: #E60012; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem; color: white; font-size: 2rem; font-weight: 700;">3</div>
                    <h4>รอรับอาหาร</h4>
                    <p class="text-muted">ดูสถานะออเดอร์แบบเรียลไทม์ รอรับอาหารได้เลย</p>
                </div>
                <div class="col col-3 col-sm-6 text-center" style="margin-bottom: 2rem;">
                    <div style="width: 80px; height: 80px; background: #E60012; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem; color: white; font-size: 2rem; font-weight: 700;">4</div>
                    <h4>ชำระเงิน</h4>
                    <p class="text-muted">เรียกพนักงานเพื่อชำระเงินเมื่อรับประทานเสร็จ</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer style="background: #333; color: white; padding: 3rem 0; text-align: center;">
        <div class="container">
            <div style="margin-bottom: 2rem;">
                <div class="logo" style="font-size: 2rem; color: white; justify-content: center; margin-bottom: 1rem;">
                    <i class="fas fa-torii-gate logo-icon"></i>
                    <span>Akatsuki Restaurant</span>
                </div>
                <p style="color: #ccc;">ร้านอาหารญี่ปุ่นต้นตำรับ</p>
            </div>
            
            <div style="margin-bottom: 2rem;">
                <h4 style="color: white; margin-bottom: 1rem;">ติดต่อเรา</h4>
                <p style="color: #ccc;"><i class="fas fa-map-marker-alt"></i> 123 ถนนสุขุมวิท กรุงเทพฯ 10110</p>
                <p style="color: #ccc;"><i class="fas fa-phone"></i> 02-XXX-XXXX</p>
                <p style="color: #ccc;"><i class="fas fa-envelope"></i> info@akatsuki-restaurant.com</p>
            </div>
            
            <div style="margin-bottom: 2rem;">
                <h4 style="color: white; margin-bottom: 1rem;">เวลาทำการ</h4>
                <p style="color: #ccc;">จันทร์ - ศุกร์: 11:00 - 22:00</p>
                <p style="color: #ccc;">เสาร์ - อาทิตย์: 10:00 - 23:00</p>
            </div>
            
            <div style="border-top: 1px solid #555; padding-top: 2rem; color: #888;">
                <p>&copy; 2025 Akatsuki Restaurant. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="assets/js/main.js"></script>
</body>
</html>
