<?php
/**
 * Order Detail Page
 * Location: staff/order-detail.php
 */

require_once '../config/database.php';
require_once '../includes/functions.php';

$db = getDB();

// Get order ID from query parameter
$orderId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$orderId) {
    header('Location: orders.php');
    exit();
}

// Get order details
$stmt = $db->prepare("
    SELECT o.*, t.table_number, t.seats,
           u.full_name as staff_name
    FROM orders o
    JOIN tables t ON o.table_id = t.table_id
    LEFT JOIN users u ON o.staff_id = u.user_id
    WHERE o.order_id = ?
");
$stmt->execute([$orderId]);
$order = $stmt->fetch();

if (!$order) {
    header('Location: orders.php');
    exit();
}

// Get order items
$stmt = $db->prepare("
    SELECT oi.*, m.name_th, m.name_en, m.image_url
    FROM order_items oi
    JOIN menu_items m ON oi.menu_id = m.menu_id
    WHERE oi.order_id = ?
    ORDER BY oi.created_at
");
$stmt->execute([$orderId]);
$orderItems = $stmt->fetchAll();

// Calculate totals
$subtotal = 0;
foreach ($orderItems as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>รายละเอียดออเดอร์ #<?= e($order['order_number']) ?> - Akatsuki Restaurant</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: #F7FAFC;
            font-family: 'Sarabun', sans-serif;
            margin: 0;
            padding: 0;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        .header-section {
            background: white;
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
        }
        
        .header-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .order-number {
            font-size: 2rem;
            font-weight: 700;
            color: #E60012;
        }
        
        .back-btn {
            padding: 0.75rem 1.5rem;
            background: #E2E8F0;
            color: #2D3748;
            border: none;
            border-radius: 8px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s;
        }
        
        .back-btn:hover {
            background: #CBD5E0;
        }
        
        .order-meta {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
        }
        
        .meta-item {
            display: flex;
            flex-direction: column;
            gap: 0.25rem;
        }
        
        .meta-label {
            font-size: 0.9rem;
            color: #718096;
        }
        
        .meta-value {
            font-size: 1.1rem;
            font-weight: 600;
            color: #2D3748;
        }
        
        .status-badge {
            display: inline-block;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
        }
        
        .status-pending { background: #FED7D7; color: #C53030; }
        .status-confirmed { background: #BEE3F8; color: #2C5282; }
        .status-cooking { background: #FBD38D; color: #975A16; }
        .status-ready { background: #C6F6D5; color: #22543D; }
        .status-served { background: #D6BCFA; color: #44337A; }
        .status-completed { background: #B2F5EA; color: #234E52; }
        .status-cancelled { background: #FED7D7; color: #742A2A; }
        
        .items-section {
            background: white;
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
        }
        
        .section-title {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            color: #2D3748;
        }
        
        .item-card {
            display: flex;
            gap: 1rem;
            padding: 1rem;
            border: 2px solid #E2E8F0;
            border-radius: 8px;
            margin-bottom: 1rem;
            transition: all 0.3s;
        }
        
        .item-card:hover {
            border-color: #E60012;
            box-shadow: 0 2px 8px rgba(230, 0, 18, 0.1);
        }
        
        .item-image {
            width: 80px;
            height: 80px;
            border-radius: 8px;
            object-fit: cover;
            background: #E2E8F0;
        }
        
        .item-details {
            flex: 1;
        }
        
        .item-name {
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 0.25rem;
            color: #2D3748;
        }
        
        .item-quantity {
            color: #718096;
            font-size: 0.9rem;
        }
        
        .item-price {
            font-size: 1.2rem;
            font-weight: 700;
            color: #E60012;
            text-align: right;
        }
        
        .special-request {
            margin-top: 0.5rem;
            padding: 0.5rem;
            background: #FFF5F5;
            border-left: 3px solid #E60012;
            border-radius: 4px;
            font-size: 0.9rem;
            color: #718096;
        }
        
        .summary-section {
            background: white;
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        .summary-row {
            display: flex;
            justify-content: space-between;
            padding: 0.75rem 0;
            border-bottom: 1px solid #E2E8F0;
        }
        
        .summary-row:last-child {
            border-bottom: none;
        }
        
        .summary-row.total {
            font-size: 1.5rem;
            font-weight: 700;
            color: #E60012;
            padding-top: 1rem;
            margin-top: 1rem;
            border-top: 2px solid #E2E8F0;
        }
        
        .actions-section {
            background: white;
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-top: 2rem;
        }
        
        .btn-group {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }
        
        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .btn-primary {
            background: #E60012;
            color: white;
        }
        
        .btn-primary:hover {
            background: #C00010;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(230, 0, 18, 0.3);
        }
        
        .btn-success {
            background: #28A745;
            color: white;
        }
        
        .btn-success:hover {
            background: #218838;
            transform: translateY(-2px);
        }
        
        .btn-warning {
            background: #FFC107;
            color: #212529;
        }
        
        .btn-warning:hover {
            background: #E0A800;
            transform: translateY(-2px);
        }
        
        .btn-danger {
            background: #DC3545;
            color: white;
        }
        
        .btn-danger:hover {
            background: #C82333;
            transform: translateY(-2px);
        }
        
        .btn-outline {
            background: white;
            color: #718096;
            border: 2px solid #E2E8F0;
        }
        
        .btn-outline:hover {
            background: #F7FAFC;
            border-color: #CBD5E0;
        }
        
        @media print {
            .back-btn, .actions-section, .btn-group {
                display: none !important;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header Section -->
        <div class="header-section">
            <div class="header-top">
                <div>
                    <div class="order-number">
                        <i class="fas fa-receipt"></i> <?= e($order['order_number']) ?>
                    </div>
                    <div style="margin-top: 0.5rem;">
                        <?php
                        $statusClass = 'status-' . $order['status'];
                        $statusText = [
                            'pending' => 'รอยืนยัน',
                            'confirmed' => 'ยืนยันแล้ว',
                            'cooking' => 'กำลังทำ',
                            'ready' => 'พร้อมเสิร์ฟ',
                            'served' => 'เสิร์ฟแล้ว',
                            'completed' => 'เสร็จสิ้น',
                            'cancelled' => 'ยกเลิก'
                        ];
                        ?>
                        <span class="status-badge <?= $statusClass ?>">
                            <?= $statusText[$order['status']] ?? $order['status'] ?>
                        </span>
                    </div>
                </div>
                <div style="display: flex; gap: 0.5rem;">
                    <a href="orders.php" class="back-btn">
                        <i class="fas fa-arrow-left"></i> กลับ
                    </a>
                    <button class="btn btn-outline" onclick="window.print()">
                        <i class="fas fa-print"></i> พิมพ์
                    </button>
                </div>
            </div>

            <div class="order-meta">
                <div class="meta-item">
                    <div class="meta-label">โต๊ะ</div>
                    <div class="meta-value">
                        <i class="fas fa-chair"></i> <?= e($order['table_number']) ?>
                        (<?= $order['seats'] ?> ที่นั่ง)
                    </div>
                </div>
                
                <div class="meta-item">
                    <div class="meta-label">วันที่สั่ง</div>
                    <div class="meta-value">
                        <i class="fas fa-clock"></i> <?= formatDateTime($order['order_date']) ?>
                    </div>
                </div>
                
                <div class="meta-item">
                    <div class="meta-label">พนักงาน</div>
                    <div class="meta-value">
                        <i class="fas fa-user"></i> <?= $order['staff_name'] ?? '-' ?>
                    </div>
                </div>
                
                <div class="meta-item">
                    <div class="meta-label">การชำระเงิน</div>
                    <div class="meta-value">
                        <?php if ($order['payment_status'] === 'paid'): ?>
                            <span style="color: #28A745;">
                                <i class="fas fa-check-circle"></i> ชำระแล้ว
                            </span>
                        <?php else: ?>
                            <span style="color: #FFC107;">
                                <i class="fas fa-clock"></i> ยังไม่ชำระ
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Order Items Section -->
        <div class="items-section">
            <h2 class="section-title">
                <i class="fas fa-utensils"></i> รายการอาหาร
            </h2>
            
            <?php foreach ($orderItems as $item): ?>
            <div class="item-card">
                <?php if ($item['image_url']): ?>
                    <img src="../assets/images/menu/<?= e($item['image_url']) ?>" 
                         alt="<?= e($item['name_th']) ?>" 
                         class="item-image"
                         onerror="this.src='../assets/images/no-image.jpg'">
                <?php else: ?>
                    <div class="item-image" style="display: flex; align-items: center; justify-content: center; color: #CBD5E0;">
                        <i class="fas fa-image" style="font-size: 2rem;"></i>
                    </div>
                <?php endif; ?>
                
                <div class="item-details">
                    <div class="item-name"><?= e($item['name_th']) ?></div>
                    <div class="item-quantity">
                        จำนวน: <?= $item['quantity'] ?> x <?= formatCurrency($item['price']) ?>
                    </div>
                    
                    <?php if ($item['special_request']): ?>
                    <div class="special-request">
                        <i class="fas fa-sticky-note"></i> 
                        <strong>หมายเหตุ:</strong> <?= e($item['special_request']) ?>
                    </div>
                    <?php endif; ?>
                    
                    <div style="margin-top: 0.5rem;">
                        <?php
                        $itemStatusClass = 'status-' . $item['status'];
                        $itemStatusText = [
                            'pending' => 'รอดำเนินการ',
                            'confirmed' => 'ยืนยันแล้ว',
                            'cooking' => 'กำลังทำ',
                            'ready' => 'พร้อม',
                            'served' => 'เสิร์ฟแล้ว',
                            'rejected' => 'ปฏิเสธ'
                        ];
                        ?>
                        <span class="status-badge <?= $itemStatusClass ?>" style="font-size: 0.8rem; padding: 0.25rem 0.75rem;">
                            <?= $itemStatusText[$item['status']] ?? $item['status'] ?>
                        </span>
                    </div>
                </div>
                
                <div class="item-price">
                    <?= formatCurrency($item['price'] * $item['quantity']) ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Summary Section -->
        <div class="summary-section">
            <h2 class="section-title">
                <i class="fas fa-calculator"></i> สรุปยอด
            </h2>
            
            <div class="summary-row">
                <div>รวมค่าอาหาร</div>
                <div><?= formatCurrency($subtotal) ?></div>
            </div>
            
            <?php if ($order['payment_status'] === 'paid' && $order['payment_method']): ?>
            <div class="summary-row">
                <div>วิธีชำระเงิน</div>
                <div>
                    <?php
                    $paymentMethods = [
                        'cash' => 'เงินสด',
                        'card' => 'บัตรเครดิต',
                        'qr_code' => 'QR Code'
                    ];
                    echo $paymentMethods[$order['payment_method']] ?? $order['payment_method'];
                    ?>
                </div>
            </div>
            
            <?php if ($order['payment_method'] === 'cash'): ?>
            <div class="summary-row">
                <div>เงินที่รับมา</div>
                <div><?= formatCurrency($order['cash_received']) ?></div>
            </div>
            
            <div class="summary-row">
                <div>เงินทอน</div>
                <div><?= formatCurrency($order['change_amount']) ?></div>
            </div>
            <?php endif; ?>
            <?php endif; ?>
            
            <div class="summary-row total">
                <div>ยอดรวมทั้งสิ้น</div>
                <div><?= formatCurrency($order['total_price']) ?></div>
            </div>
        </div>

        <!-- Actions Section -->
        <?php if ($order['payment_status'] === 'unpaid'): ?>
        <div class="actions-section">
            <h2 class="section-title">
                <i class="fas fa-cogs"></i> จัดการ
            </h2>
            
            <div class="btn-group">
                <?php if ($order['status'] === 'pending'): ?>
                <button class="btn btn-success" onclick="updateOrderStatus('confirmed')">
                    <i class="fas fa-check"></i> ยืนยันออเดอร์
                </button>
                <button class="btn btn-danger" onclick="updateOrderStatus('cancelled')">
                    <i class="fas fa-times"></i> ยกเลิกออเดอร์
                </button>
                
                <?php elseif ($order['status'] === 'ready'): ?>
                <button class="btn btn-primary" onclick="updateOrderStatus('served')">
                    <i class="fas fa-check-double"></i> เสิร์ฟแล้ว
                </button>
                <?php endif; ?>
                
                <a href="payment.php?order=<?= $order['order_id'] ?>" class="btn btn-warning">
                    <i class="fas fa-cash-register"></i> ชำระเงิน
                </a>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <script src="../assets/js/main.js"></script>
    <script>
        async function updateOrderStatus(status) {
            const statusText = {
                'confirmed': 'ยืนยัน',
                'cancelled': 'ยกเลิก',
                'served': 'เสิร์ฟแล้ว'
            };
            
            const confirmed = confirm(`ต้องการ${statusText[status]}ออเดอร์นี้?`);
            if (!confirmed) return;

            try {
                const response = await fetch('../api/orders.php', {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'update_status',
                        order_id: <?= $orderId ?>,
                        status: status
                    })
                });

                const result = await response.json();

                if (result.success) {
                    // If the order was confirmed, notify the ready-orders page so it can record/show the confirmed order
                    if (status === 'confirmed') {
                        try {
                            await fetch('ready-orders.php', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ action: 'notify_confirmed', order_id: <?= $orderId ?> })
                            });
                        } catch (notifyErr) {
                            console.warn('Notify ready-orders.php failed', notifyErr);
                        }
                    }

                    alert('อัปเดตสถานะสำเร็จ');
                    location.reload();
                } else {
                    alert(result.message || 'เกิดข้อผิดพลาด');
                }
            } catch (error) {
                console.error('Error:', error);
                alert('เกิดข้อผิดพลาด');
            }
        }
    </script>
</body>
</html>
