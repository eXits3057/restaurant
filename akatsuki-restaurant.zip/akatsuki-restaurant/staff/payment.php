<?php
/**
 * Payment Processing
 * Location: staff/payment.php
 */

require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/staff_auth.php';

$db = getDB();

// Get table ID or order ID
$tableId = isset($_GET['table']) ? (int)$_GET['table'] : null;
$orderId = isset($_GET['order']) ? (int)$_GET['order'] : null;

$table = null;
$session = null;
$orders = [];
$total = 0;

if ($tableId) {
    // Get table info
    $stmt = $db->prepare("SELECT * FROM tables WHERE table_id = ?");
    $stmt->execute([$tableId]);
    $table = $stmt->fetch();
    
    if ($table && $table['current_session_id']) {
        // Get session info
        $stmt = $db->prepare("SELECT * FROM sessions WHERE session_id = ?");
        $stmt->execute([$table['current_session_id']]);
        $session = $stmt->fetch();
        
        // Get unpaid orders
        $stmt = $db->prepare("
            SELECT o.*, COUNT(oi.order_item_id) as item_count
            FROM orders o
            LEFT JOIN order_items oi ON o.order_id = oi.order_id
            WHERE o.session_id = ? AND o.payment_status = 'unpaid'
            GROUP BY o.order_id
            ORDER BY o.order_date
        ");
        $stmt->execute([$session['session_id']]);
        $orders = $stmt->fetchAll();
        
        $total = array_sum(array_column($orders, 'total_price'));
    }
} elseif ($orderId) {
    // Get single order
    $stmt = $db->prepare("
        SELECT o.*, t.table_number, t.table_id, s.session_id
        FROM orders o
        JOIN tables t ON o.table_id = t.table_id
        LEFT JOIN sessions s ON o.session_id = s.session_id
        WHERE o.order_id = ?
    ");
    $stmt->execute([$orderId]);
    $order = $stmt->fetch();
    
    if ($order) {
        $orders = [$order];
        $total = $order['total_price'];
        $table = ['table_id' => $order['table_id'], 'table_number' => $order['table_number']];
        $session = ['session_id' => $order['session_id']];
    }
}

// Handle payment submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($orders)) {
    $paymentMethod = sanitize($_POST['payment_method'] ?? '');
    $cashReceived = isset($_POST['cash_received']) ? floatval($_POST['cash_received']) : 0;
    
    if (empty($paymentMethod)) {
        $error = 'กรุณาเลือกวิธีชำระเงิน';
    } elseif ($paymentMethod === 'cash' && $cashReceived < $total) {
        $error = 'จำนวนเงินไม่เพียงพอ';
    } else {
        $change = $paymentMethod === 'cash' ? $cashReceived - $total : 0;
        
        $db->beginTransaction();
        
        try {
            // Update all orders
            $stmt = $db->prepare("
                UPDATE orders 
                SET payment_status = 'paid',
                    payment_method = ?,
                    cash_received = ?,
                    change_amount = ?,
                    completed_at = NOW(),
                    status = 'completed',
                    staff_id = ?
                WHERE order_id = ?
            ");
            
            foreach ($orders as $order) {
                $stmt->execute([
                    $paymentMethod,
                    $paymentMethod === 'cash' ? $cashReceived : null,
                    $paymentMethod === 'cash' ? $change : null,
                    getCurrentUserId(),
                    $order['order_id']
                ]);
            }
            
            // End session and update table
            if ($session) {
                $stmt = $db->prepare("
                    UPDATE sessions 
                    SET end_time = NOW(), total_amount = ? 
                    WHERE session_id = ?
                ");
                $stmt->execute([$total, $session['session_id']]);
                
                $stmt = $db->prepare("
                    UPDATE tables 
                    SET status = 'cleaning', current_session_id = NULL 
                    WHERE table_id = ?
                ");
                $stmt->execute([$table['table_id']]);
            }
            
            $db->commit();
            
            $success = true;
            $changeAmount = $change;
        } catch (Exception $e) {
            $db->rollBack();
            $error = 'เกิดข้อผิดพลาด: ' . $e->getMessage();
        }
    }
}

$staffInfo = [
    'full_name' => 'Staff',
    'role' => 'staff'
];
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ชำระเงิน - Akatsuki Restaurant</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .staff-header {
            background: white;
            box-shadow: var(--shadow);
            padding: 1rem 0;
            margin-bottom: 2rem;
        }
        
        .staff-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .staff-nav-links {
            display: flex;
            gap: 1rem;
            list-style: none;
        }
        
        .staff-nav-link {
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: var(--transition);
            color: var(--text-dark);
        }
        
        .staff-nav-link:hover {
            background: var(--bg-light);
        }
        
        .staff-nav-link.active {
            background: var(--primary-color);
            color: white;
        }
        
        .payment-container {
            max-width: 1000px;
            margin: 0 auto;
        }
        
        .total-display {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            color: white;
            padding: 2rem;
            border-radius: 16px;
            text-align: center;
            margin-bottom: 2rem;
            box-shadow: 0 8px 32px rgba(230, 0, 18, 0.3);
        }
        
        .total-amount {
            font-size: 4rem;
            font-weight: 700;
            margin: 1rem 0;
        }
        
        .payment-method-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }
        
        .payment-method-card {
            background: white;
            border: 3px solid var(--border-color);
            border-radius: 12px;
            padding: 2rem;
            text-align: center;
            cursor: pointer;
            transition: var(--transition);
        }
        
        .payment-method-card:hover {
            border-color: var(--primary-color);
            transform: translateY(-5px);
            box-shadow: var(--shadow-hover);
        }
        
        .payment-method-card.selected {
            border-color: var(--primary-color);
            background: #FFF5F5;
        }
        
        .payment-method-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: var(--primary-color);
        }
        
        .calculator-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 0.75rem;
            margin-top: 1rem;
        }
        
        .calc-btn {
            padding: 1.5rem;
            font-size: 1.5rem;
            font-weight: 700;
            border: 2px solid var(--border-color);
            background: white;
            border-radius: 12px;
            cursor: pointer;
            transition: var(--transition);
        }
        
        .calc-btn:hover {
            background: var(--bg-light);
            border-color: var(--primary-color);
        }
        
        .calc-btn:active {
            transform: scale(0.95);
        }
        
        .quick-amount-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 0.75rem;
            margin-top: 1rem;
        }
        
        .quick-amount-btn {
            padding: 1rem;
            font-size: 1.1rem;
            font-weight: 600;
            background: var(--bg-light);
            border: 2px solid var(--border-color);
            border-radius: 8px;
            cursor: pointer;
            transition: var(--transition);
        }
        
        .quick-amount-btn:hover {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }
        
        .change-display {
            background: #E8F5E9;
            border: 3px solid #28A745;
            padding: 2rem;
            border-radius: 16px;
            text-align: center;
            margin-top: 2rem;
        }
        
        .change-amount {
            font-size: 3rem;
            font-weight: 700;
            color: #28A745;
        }
        
        .success-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
        }
        
        .success-content {
            background: white;
            padding: 3rem;
            border-radius: 20px;
            text-align: center;
            max-width: 500px;
            animation: slideIn 0.3s ease;
        }
        
        @keyframes slideIn {
            from { transform: scale(0.8); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }
        
        .success-icon {
            font-size: 5rem;
            color: #28A745;
            margin-bottom: 1rem;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.5rem 1rem;
            background: var(--bg-light);
            border-radius: 25px;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
        }
    </style>
</head>
<body>
    <!-- Staff Header -->
    <header class="staff-header">
        <div class="container">
            <nav class="staff-nav">
                <div class="logo">
                    <i class="fas fa-torii-gate logo-icon"></i>
                    <span>Akatsuki Staff</span>
                </div>
                
                <ul class="staff-nav-links">
                    <li><a href="dashboard.php" class="staff-nav-link"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="orders.php" class="staff-nav-link"><i class="fas fa-receipt"></i> ออเดอร์</a></li>
                    <li><a href="ready-orders.php" class="staff-nav-link"><i class="fas fa-bell"></i> พร้อมเสิร์ฟ</a></li>
                    <li><a href="tables.php" class="staff-nav-link"><i class="fas fa-chair"></i> โต๊ะ</a></li>
                    <li><a href="payment.php" class="staff-nav-link active"><i class="fas fa-cash-register"></i> ชำระเงิน</a></li>
                </ul>
                
                <div class="user-info">
                    <div class="user-avatar">
                        <?= strtoupper(substr($staffInfo['full_name'], 0, 2)) ?>
                    </div>
                    <div>
                        <div style="font-weight: 600;"><?= e($staffInfo['full_name']) ?></div>
                        <div style="font-size: 0.85rem; color: var(--text-light);"><?= e($staffInfo['role']) ?></div>
                    </div>
                    <a href="logout.php" style="color: var(--danger-color); margin-left: 0.5rem;" title="ออกจากระบบ">
                        <i class="fas fa-sign-out-alt"></i>
                    </a>
                </div>
            </nav>
        </div>
    </header>

    <section class="section">
        <div class="container">
            <div class="payment-container">
                <h1 style="margin-bottom: 2rem;">
                    <i class="fas fa-cash-register"></i> ชำระเงิน
                    <?php if ($table): ?>
                    - โต๊ะ <?= e($table['table_number']) ?>
                    <?php endif; ?>
                </h1>

                <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?= e($error) ?>
                </div>
                <?php endif; ?>

                <?php if (empty($orders)): ?>
                <div class="card">
                    <div class="card-body text-center" style="padding: 3rem;">
                        <div style="font-size: 4rem; color: var(--text-light); margin-bottom: 1rem;">
                            <i class="fas fa-receipt"></i>
                        </div>
                        <h3>ไม่พบรายการที่ต้องชำระเงิน</h3>
                        <p class="text-muted">โปรดเลือกโต๊ะหรือออเดอร์ที่ต้องการชำระเงิน</p>
                        <div style="margin-top: 2rem;">
                            <a href="tables.php" class="btn btn-primary">
                                <i class="fas fa-chair"></i> ไปที่จัดการโต๊ะ
                            </a>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <form method="POST" id="paymentForm">
                    <!-- Total Display -->
                    <div class="total-display">
                        <div style="font-size: 1.2rem; opacity: 0.9;">ยอดที่ต้องชำระ</div>
                        <div class="total-amount" id="totalAmount">
                            <?= formatCurrency($total) ?>
                        </div>
                        <div style="opacity: 0.9;">
                            <?= count($orders) ?> ออเดอร์
                        </div>
                    </div>

                    <!-- Payment Method Selection -->
                    <div class="card">
                        <div class="card-body">
                            <h3 style="margin-bottom: 1.5rem;">เลือกวิธีชำระเงิน</h3>
                            
                            <div class="payment-method-grid">
                                <div class="payment-method-card" onclick="selectPaymentMethod('cash')">
                                    <input type="radio" name="payment_method" value="cash" id="cash" style="display: none;">
                                    <div class="payment-method-icon">
                                        <i class="fas fa-money-bill-wave"></i>
                                    </div>
                                    <div style="font-weight: 600;">เงินสด</div>
                                </div>
                                
                                <div class="payment-method-card" onclick="selectPaymentMethod('card')">
                                    <input type="radio" name="payment_method" value="card" id="card" style="display: none;">
                                    <div class="payment-method-icon">
                                        <i class="fas fa-credit-card"></i>
                                    </div>
                                    <div style="font-weight: 600;">บัตรเครดิต</div>
                                </div>
                                
                                <div class="payment-method-card" onclick="selectPaymentMethod('qr_code')">
                                    <input type="radio" name="payment_method" value="qr_code" id="qr_code" style="display: none;">
                                    <div class="payment-method-icon">
                                        <i class="fas fa-qrcode"></i>
                                    </div>
                                    <div style="font-weight: 600;">QR Code</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Cash Payment Section -->
                    <div id="cashPaymentSection" style="display: none; margin-top: 2rem;">
                        <div class="card">
                            <div class="card-body">
                                <h3 style="margin-bottom: 1.5rem;">ป้อนจำนวนเงินที่รับมา</h3>
                                
                                <input type="number" 
                                       class="form-control" 
                                       id="cashReceived" 
                                       name="cash_received"
                                       placeholder="0.00" 
                                       step="0.01"
                                       style="text-align: center; font-size: 2rem; font-weight: 700; padding: 1.5rem;"
                                       readonly>

                                <!-- Quick Amount Buttons -->
                                <div class="quick-amount-grid">
                                    <button type="button" class="quick-amount-btn" onclick="addAmount(20)">+20</button>
                                    <button type="button" class="quick-amount-btn" onclick="addAmount(50)">+50</button>
                                    <button type="button" class="quick-amount-btn" onclick="addAmount(100)">+100</button>
                                    <button type="button" class="quick-amount-btn" onclick="addAmount(500)">+500</button>
                                    <button type="button" class="quick-amount-btn" onclick="addAmount(1000)">+1,000</button>
                                    <button type="button" class="quick-amount-btn" onclick="setExactAmount()">พอดี</button>
                                </div>

                                <!-- Calculator -->
                                <div class="calculator-grid">
                                    <button type="button" class="calc-btn" onclick="appendNumber('1')">1</button>
                                    <button type="button" class="calc-btn" onclick="appendNumber('2')">2</button>
                                    <button type="button" class="calc-btn" onclick="appendNumber('3')">3</button>
                                    <button type="button" class="calc-btn" onclick="appendNumber('4')">4</button>
                                    <button type="button" class="calc-btn" onclick="appendNumber('5')">5</button>
                                    <button type="button" class="calc-btn" onclick="appendNumber('6')">6</button>
                                    <button type="button" class="calc-btn" onclick="appendNumber('7')">7</button>
                                    <button type="button" class="calc-btn" onclick="appendNumber('8')">8</button>
                                    <button type="button" class="calc-btn" onclick="appendNumber('9')">9</button>
                                    <button type="button" class="calc-btn" onclick="appendNumber('0')" style="grid-column: span 2;">0</button>
                                    <button type="button" class="calc-btn" onclick="clearAmount()" style="background: #DC3545; color: white;">C</button>
                                </div>

                                <!-- Change Display -->
                                <div id="changeDisplay" style="display: none;">
                                    <div class="change-display">
                                        <div style="font-size: 1.2rem; margin-bottom: 0.5rem;">เงินทอน</div>
                                        <div class="change-amount" id="changeAmount">฿0.00</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Action Buttons -->
                    <div style="display: flex; gap: 1rem; margin-top: 2rem;">
                        <a href="tables.php" class="btn btn-outline btn-lg" style="flex: 1;">
                            <i class="fas fa-times"></i> ยกเลิก
                        </a>
                        <button type="submit" class="btn btn-success btn-lg" style="flex: 2;" id="confirmBtn" disabled>
                            <i class="fas fa-check"></i> ยืนยันการชำระเงิน
                        </button>
                    </div>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Success Modal -->
    <?php if (isset($success) && $success): ?>
    <div class="success-modal" id="successModal">
        <div class="success-content">
            <div class="success-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <h2>ชำระเงินสำเร็จ!</h2>
            <?php if (isset($changeAmount) && $changeAmount > 0): ?>
            <div style="margin: 2rem 0;">
                <div style="font-size: 1.2rem; color: var(--text-light);">เงินทอน</div>
                <div style="font-size: 3rem; font-weight: 700; color: #28A745;">
                    <?= formatCurrency($changeAmount) ?>
                </div>
            </div>
            <?php endif; ?>
            <p style="margin: 1.5rem 0;">ยอดชำระ: <strong><?= formatCurrency($total) ?></strong></p>
            <button class="btn btn-primary btn-lg" onclick="window.location.href='tables.php'">
                <i class="fas fa-home"></i> กลับหน้าหลัก
            </button>
        </div>
    </div>
    <?php endif; ?>

    <script src="../assets/js/main.js"></script>
    <script>
        const totalAmount = <?= $total ?>;
        let selectedMethod = '';
        let cashReceived = 0;

        function selectPaymentMethod(method) {
            selectedMethod = method;
            
            // Update UI
            document.querySelectorAll('.payment-method-card').forEach(card => {
                card.classList.remove('selected');
            });
            event.currentTarget.classList.add('selected');
            
            // Check radio
            document.getElementById(method).checked = true;
            
            // Show/hide cash section
            const cashSection = document.getElementById('cashPaymentSection');
            if (method === 'cash') {
                cashSection.style.display = 'block';
                document.getElementById('confirmBtn').disabled = true;
            } else {
                cashSection.style.display = 'none';
                document.getElementById('confirmBtn').disabled = false;
            }
        }

        function appendNumber(num) {
            const input = document.getElementById('cashReceived');
            let current = input.value.replace(/,/g, '');
            
            if (current === '0' || current === '') {
                current = num;
            } else {
                current += num;
            }
            
            input.value = parseFloat(current);
            updateChange();
        }

        function clearAmount() {
            document.getElementById('cashReceived').value = '';
            updateChange();
        }

        function addAmount(amount) {
            const input = document.getElementById('cashReceived');
            let current = parseFloat(input.value) || 0;
            input.value = current + amount;
            updateChange();
        }

        function setExactAmount() {
            document.getElementById('cashReceived').value = totalAmount;
            updateChange();
        }

        function updateChange() {
            const input = document.getElementById('cashReceived');
            cashReceived = parseFloat(input.value) || 0;
            const change = cashReceived - totalAmount;
            
            const changeDisplay = document.getElementById('changeDisplay');
            const changeAmount = document.getElementById('changeAmount');
            const confirmBtn = document.getElementById('confirmBtn');
            
            if (change >= 0) {
                changeDisplay.style.display = 'block';
                changeAmount.textContent = '฿' + change.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
                confirmBtn.disabled = false;
            } else {
                changeDisplay.style.display = 'none';
                confirmBtn.disabled = true;
            }
        }

        // Form validation
        document.getElementById('paymentForm')?.addEventListener('submit', function(e) {
            if (!selectedMethod) {
                e.preventDefault();
                Utils.showToast('กรุณาเลือกวิธีชำระเงิน', 'error');
                return;
            }
            
            if (selectedMethod === 'cash' && cashReceived < totalAmount) {
                e.preventDefault();
                Utils.showToast('จำนวนเงินไม่เพียงพอ', 'error');
                return;
            }
        });
    </script>
</body>
</html>
