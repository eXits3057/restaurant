<?php
/**
 * Staff Orders Management
 * Location: staff/orders.php
 */

require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/staff_auth.php';

$db = getDB();

// Filter parameters
$statusFilter = $_GET['status'] ?? 'all';
$dateFilter = $_GET['date'] ?? date('Y-m-d');

// Build query
$query = "
    SELECT o.*, t.table_number, COUNT(oi.order_item_id) as item_count
    FROM orders o
    JOIN tables t ON o.table_id = t.table_id
    LEFT JOIN order_items oi ON o.order_id = oi.order_id
    WHERE DATE(o.order_date) = ?
";

$params = [$dateFilter];

if ($statusFilter !== 'all') {
    $query .= " AND o.status = ?";
    $params[] = $statusFilter;
}

$query .= " GROUP BY o.order_id ORDER BY o.order_date DESC";

$stmt = $db->prepare($query);
$stmt->execute($params);
$orders = $stmt->fetchAll();

$staffInfo = [
    'full_name' => 'Staff',
    'role' => 'staff'
];
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>จัดการออเดอร์ - Akatsuki Restaurant</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .staff-header {
            background: white;
            box-shadow: var(--shadow);
            padding: 1rem 0;
            margin-bottom: 2rem;
        }
        
        .staff-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .staff-nav-links {
            display: flex;
            gap: 1rem;
            list-style: none;
        }
        
        .staff-nav-link {
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: var(--transition);
            color: var(--text-dark);
        }
        
        .staff-nav-link:hover {
            background: var(--bg-light);
        }
        
        .staff-nav-link.active {
            background: var(--primary-color);
            color: white;
        }
        
        .filter-bar {
            background: white;
            padding: 1.5rem;
            border-radius: 12px;
            box-shadow: var(--shadow);
            margin-bottom: 2rem;
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
            align-items: center;
        }
        
        .filter-group {
            flex: 1;
            min-width: 200px;
        }
        
        .order-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: var(--shadow);
            margin-bottom: 1.5rem;
            transition: var(--transition);
        }
        
        .order-card:hover {
            box-shadow: var(--shadow-hover);
        }
        
        .order-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--border-color);
        }
        
        .order-number {
            font-size: 1.3rem;
            font-weight: 700;
            color: var(--primary-color);
        }
        
        .order-meta {
            display: flex;
            gap: 1.5rem;
            margin-bottom: 1rem;
            color: var(--text-light);
            font-size: 0.9rem;
        }
        
        .order-actions {
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.5rem 1rem;
            background: var(--bg-light);
            border-radius: 25px;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
        }
    </style>
</head>
<body>
    <!-- Staff Header -->
    <header class="staff-header">
        <div class="container">
            <nav class="staff-nav">
                <div class="logo">
                    <i class="fas fa-torii-gate logo-icon"></i>
                    <span>Akatsuki Staff</span>
                </div>
                
                <ul class="staff-nav-links">
                    <li><a href="dashboard.php" class="staff-nav-link"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="orders.php" class="staff-nav-link active"><i class="fas fa-receipt"></i> ออเดอร์</a></li>
                    <li><a href="ready-orders.php" class="staff-nav-link"><i class="fas fa-bell"></i> พร้อมเสิร์ฟ</a></li>
                    <li><a href="tables.php" class="staff-nav-link"><i class="fas fa-chair"></i> โต๊ะ</a></li>
                    <li><a href="payment.php" class="staff-nav-link"><i class="fas fa-cash-register"></i> ชำระเงิน</a></li>
                </ul>
                
                <div class="user-info">
                    <div class="user-avatar">
                        <?= strtoupper(substr($staffInfo['full_name'], 0, 2)) ?>
                    </div>
                    <div>
                        <div style="font-weight: 600;"><?= e($staffInfo['full_name']) ?></div>
                        <div style="font-size: 0.85rem; color: var(--text-light);"><?= e($staffInfo['role']) ?></div>
                    </div>
                    <a href="logout.php" style="color: var(--danger-color); margin-left: 0.5rem;" title="ออกจากระบบ">
                        <i class="fas fa-sign-out-alt"></i>
                    </a>
                </div>
            </nav>
        </div>
    </header>

    <section class="section">
        <div class="container">
            <h1 style="margin-bottom: 2rem;">
                <i class="fas fa-receipt"></i> จัดการออเดอร์
            </h1>

            <!-- Filter Bar -->
            <div class="filter-bar">
                <div class="filter-group">
                    <label class="form-label">วันที่</label>
                    <input type="date" 
                           class="form-control" 
                           id="dateFilter" 
                           value="<?= e($dateFilter) ?>"
                           onchange="applyFilters()">
                </div>
                
                <div class="filter-group">
                    <label class="form-label">สถานะ</label>
                    <select class="form-control" id="statusFilter" onchange="applyFilters()">
                        <option value="all" <?= $statusFilter === 'all' ? 'selected' : '' ?>>ทั้งหมด</option>
                        <option value="pending" <?= $statusFilter === 'pending' ? 'selected' : '' ?>>รอยืนยัน</option>
                        <option value="confirmed" <?= $statusFilter === 'confirmed' ? 'selected' : '' ?>>ยืนยันแล้ว</option>
                        <option value="cooking" <?= $statusFilter === 'cooking' ? 'selected' : '' ?>>กำลังทำ</option>
                        <option value="ready" <?= $statusFilter === 'ready' ? 'selected' : '' ?>>พร้อมเสิร์ฟ</option>
                        <option value="served" <?= $statusFilter === 'served' ? 'selected' : '' ?>>เสิร์ฟแล้ว</option>
                        <option value="completed" <?= $statusFilter === 'completed' ? 'selected' : '' ?>>เสร็จสิ้น</option>
                    </select>
                </div>
                
                <div style="margin-top: auto;">
                    <button class="btn btn-outline" onclick="resetFilters()">
                        <i class="fas fa-redo"></i> รีเซ็ต
                    </button>
                </div>
            </div>

            <!-- Orders List -->
            <?php if (empty($orders)): ?>
            <div class="card">
                <div class="card-body text-center" style="padding: 3rem;">
                    <div style="font-size: 4rem; color: var(--text-light); margin-bottom: 1rem;">
                        <i class="fas fa-inbox"></i>
                    </div>
                    <h3>ไม่พบออเดอร์</h3>
                    <p class="text-muted">ไม่มีออเดอร์ตามเงื่อนไขที่เลือก</p>
                </div>
            </div>
            <?php else: ?>
            <?php foreach ($orders as $order): ?>
            <div class="order-card">
                <div class="order-header">
                    <div>
                        <div class="order-number">
                            <i class="fas fa-receipt"></i> <?= e($order['order_number']) ?>
                        </div>
                        <div style="font-size: 0.9rem; color: var(--text-light); margin-top: 0.25rem;">
                            โต๊ะ <?= e($order['table_number']) ?> • <?= $order['item_count'] ?> รายการ
                        </div>
                    </div>
                    <div>
                        <?= getStatusBadge($order['status']) ?>
                    </div>
                </div>

                <div class="order-meta">
                    <div>
                        <i class="fas fa-clock"></i>
                        <?= formatDateTime($order['order_date']) ?>
                    </div>
                    <div>
                        <i class="fas fa-dollar-sign"></i>
                        <?= formatCurrency($order['total_price']) ?>
                    </div>
                    <div>
                        <?= getPaymentStatusBadge($order['payment_status']) ?>
                    </div>
                </div>

                <div class="order-actions">
                    <a href="order-detail.php?id=<?= $order['order_id'] ?>" class="btn btn-sm btn-outline">
                        <i class="fas fa-eye"></i> ดูรายละเอียด
                    </a>
                    
                    <?php if ($order['status'] === 'pending'): ?>
                    <button class="btn btn-sm btn-success" onclick="confirmOrder(<?= $order['order_id'] ?>)">
                        <i class="fas fa-check"></i> ยืนยัน
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="cancelOrder(<?= $order['order_id'] ?>)">
                        <i class="fas fa-times"></i> ยกเลิก
                    </button>
                    <?php elseif ($order['status'] === 'ready'): ?>
                    <button class="btn btn-sm btn-primary" onclick="markServed(<?= $order['order_id'] ?>)">
                        <i class="fas fa-check-double"></i> เสิร์ฟแล้ว
                    </button>
                    <?php endif; ?>
                    
                    <?php if ($order['payment_status'] === 'unpaid'): ?>
                    <a href="payment.php?order=<?= $order['order_id'] ?>" class="btn btn-sm btn-warning">
                        <i class="fas fa-cash-register"></i> ชำระเงิน
                    </a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </section>

    <script src="../assets/js/main.js"></script>
    <script>
        function applyFilters() {
            const date = document.getElementById('dateFilter').value;
            const status = document.getElementById('statusFilter').value;
            window.location.href = `orders.php?date=${date}&status=${status}`;
        }

        function resetFilters() {
            window.location.href = 'orders.php';
        }

        async function confirmOrder(orderId) {
            const confirmed = await Utils.confirm('ยืนยันออเดอร์นี้?');
            if (!confirmed) return;

            Utils.showLoading();

            try {
                const response = await fetch('../api/orders.php', {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'update_status',
                        order_id: orderId,
                        status: 'confirmed'
                    })
                });

                const result = await response.json();

                if (result.success) {
                    // Notify ready-orders.php so it can record/show the confirmed order
                    // We don't block the user if notification fails — it's best-effort.
                    try {
                        await fetch('ready-orders.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ action: 'notify_confirmed', order_id: orderId })
                        });
                    } catch (notifyErr) {
                        console.warn('Notify ready-orders.php failed', notifyErr);
                    }

                    Utils.showToast('ยืนยันออเดอร์สำเร็จ', 'success');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    Utils.showToast(result.message || 'เกิดข้อผิดพลาด', 'error');
                }
            } catch (error) {
                console.error('Error:', error);
                Utils.showToast('เกิดข้อผิดพลาด', 'error');
            } finally {
                Utils.hideLoading();
            }
        }

        async function cancelOrder(orderId) {
            const confirmed = await Utils.confirm('ยกเลิกออเดอร์นี้?');
            if (!confirmed) return;

            Utils.showLoading();

            try {
                const response = await fetch('../api/orders.php', {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'update_status',
                        order_id: orderId,
                        status: 'cancelled'
                    })
                });

                const result = await response.json();

                if (result.success) {
                    Utils.showToast('ยกเลิกออเดอร์สำเร็จ', 'success');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    Utils.showToast(result.message || 'เกิดข้อผิดพลาด', 'error');
                }
            } catch (error) {
                console.error('Error:', error);
                Utils.showToast('เกิดข้อผิดพลาด', 'error');
            } finally {
                Utils.hideLoading();
            }
        }

        async function markServed(orderId) {
            const confirmed = await Utils.confirm('ยืนยันว่าเสิร์ฟแล้ว?');
            if (!confirmed) return;

            Utils.showLoading();

            try {
                const response = await fetch('../api/orders.php', {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'update_status',
                        order_id: orderId,
                        status: 'served'
                    })
                });

                const result = await response.json();

                if (result.success) {
                    Utils.showToast('อัปเดตสถานะสำเร็จ', 'success');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    Utils.showToast(result.message || 'เกิดข้อผิดพลาด', 'error');
                }
            } catch (error) {
                console.error('Error:', error);
                Utils.showToast('เกิดข้อผิดพลาด', 'error');
            } finally {
                Utils.hideLoading();
            }
        }

        // Auto refresh every 30 seconds
        setInterval(() => {
            location.reload();
        }, 30000);
    </script>
</body>
</html>
