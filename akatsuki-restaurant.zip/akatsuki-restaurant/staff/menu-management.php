<?php
/**
 * Menu Management (CRUD)
 * Location: staff/menu-management.php
 */

require_once '../config/database.php';
require_once '../includes/functions.php';

$db = getDB();

// Get all categories for dropdown
$stmt = $db->query("SELECT * FROM categories ORDER BY display_order, name");
$categories = $stmt->fetchAll();

// Handle form submission (Create/Update)
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'create' || $action === 'update') {
        $menuId = $action === 'update' ? (int)$_POST['menu_id'] : null;
        $categoryId = (int)$_POST['category_id'];
        $nameTh = sanitize($_POST['name_th']);
        $nameEn = sanitize($_POST['name_en']);
        $description = sanitize($_POST['description']);
        $price = floatval($_POST['price']);
        $cost = floatval($_POST['cost']);
        $isAvailable = isset($_POST['is_available']) ? 1 : 0;
        
        // Handle image upload
        $imageUrl = $_POST['existing_image'] ?? '';
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = '../assets/images/menu/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            
            $fileExt = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $fileName = uniqid('menu_') . '.' . $fileExt;
            $uploadPath = $uploadDir . $fileName;
            
            if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadPath)) {
                $imageUrl = $fileName;
            }
        }
        
        try {
            if ($action === 'create') {
                $stmt = $db->prepare("
                    INSERT INTO menu_items 
                    (category_id, name_th, name_en, description, price, cost, image_url, is_available)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([$categoryId, $nameTh, $nameEn, $description, $price, $cost, $imageUrl, $isAvailable]);
                $success = 'เพิ่มเมนูสำเร็จ!';
            } else {
                $stmt = $db->prepare("
                    UPDATE menu_items 
                    SET category_id = ?, name_th = ?, name_en = ?, description = ?, 
                        price = ?, cost = ?, image_url = ?, is_available = ?
                    WHERE menu_id = ?
                ");
                $stmt->execute([$categoryId, $nameTh, $nameEn, $description, $price, $cost, $imageUrl, $isAvailable, $menuId]);
                $success = 'อัปเดตเมนูสำเร็จ!';
            }
        } catch (PDOException $e) {
            $error = 'เกิดข้อผิดพลาด: ' . $e->getMessage();
        }
    }
    
    if ($action === 'delete') {
        $menuId = (int)$_POST['menu_id'];
        try {
            $stmt = $db->prepare("DELETE FROM menu_items WHERE menu_id = ?");
            $stmt->execute([$menuId]);
            $success = 'ลบเมนูสำเร็จ!';
        } catch (PDOException $e) {
            $error = 'ไม่สามารถลบเมนูได้: ' . $e->getMessage();
        }
    }
}

// Get filter
$categoryFilter = isset($_GET['category']) ? (int)$_GET['category'] : 0;
$searchQuery = isset($_GET['search']) ? sanitize($_GET['search']) : '';

// Build query
$query = "SELECT m.*, c.name as category_name FROM menu_items m 
          LEFT JOIN categories c ON m.category_id = c.category_id WHERE 1=1";
$params = [];

if ($categoryFilter > 0) {
    $query .= " AND m.category_id = ?";
    $params[] = $categoryFilter;
}

if ($searchQuery) {
    $query .= " AND (m.name_th LIKE ? OR m.name_en LIKE ?)";
    $params[] = "%$searchQuery%";
    $params[] = "%$searchQuery%";
}

$query .= " ORDER BY m.category_id, m.name_th";

$stmt = $db->prepare($query);
$stmt->execute($params);
$menuItems = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>จัดการเมนูอาหาร - Akatsuki Restaurant</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: #F7FAFC;
            font-family: 'Sarabun', sans-serif;
            margin: 0;
            padding: 0;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .header h1 {
            font-size: 2rem;
            color: #2D3748;
            margin: 0;
        }
        
        .filter-section {
            background: white;
            padding: 1.5rem;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
        }
        
        .filter-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1rem;
            align-items: end;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }
        
        .form-label {
            font-weight: 600;
            color: #2D3748;
        }
        
        .form-control {
            padding: 0.75rem;
            border: 2px solid #E2E8F0;
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #E60012;
            box-shadow: 0 0 0 3px rgba(230, 0, 18, 0.1);
        }
        
        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            justify-content: center;
        }
        
        .btn-primary {
            background: #E60012;
            color: white;
        }
        
        .btn-primary:hover {
            background: #C00010;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(230, 0, 18, 0.3);
        }
        
        .btn-success {
            background: #28A745;
            color: white;
        }
        
        .btn-warning {
            background: #FFC107;
            color: #212529;
        }
        
        .btn-danger {
            background: #DC3545;
            color: white;
        }
        
        .btn-outline {
            background: white;
            color: #718096;
            border: 2px solid #E2E8F0;
        }
        
        .btn-sm {
            padding: 0.5rem 1rem;
            font-size: 0.9rem;
        }
        
        .menu-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1.5rem;
        }
        
        .menu-card {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            transition: all 0.3s;
        }
        
        .menu-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 4px 16px rgba(0,0,0,0.15);
        }
        
        .menu-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            background: #E2E8F0;
        }
        
        .menu-content {
            padding: 1.5rem;
        }
        
        .menu-name {
            font-size: 1.2rem;
            font-weight: 700;
            color: #2D3748;
            margin-bottom: 0.5rem;
        }
        
        .menu-category {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            background: #E2E8F0;
            color: #2D3748;
            border-radius: 12px;
            font-size: 0.85rem;
            margin-bottom: 0.5rem;
        }
        
        .menu-description {
            color: #718096;
            font-size: 0.9rem;
            margin-bottom: 1rem;
            line-height: 1.5;
        }
        
        .menu-price {
            font-size: 1.5rem;
            font-weight: 700;
            color: #E60012;
            margin-bottom: 1rem;
        }
        
        .menu-status {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 12px;
            font-size: 0.85rem;
            font-weight: 600;
        }
        
        .status-available {
            background: #C6F6D5;
            color: #22543D;
        }
        
        .status-unavailable {
            background: #FED7D7;
            color: #742A2A;
        }
        
        .menu-actions {
            display: flex;
            gap: 0.5rem;
            margin-top: 1rem;
        }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            overflow-y: auto;
        }
        
        .modal.active {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
        }
        
        .modal-content {
            background: white;
            border-radius: 12px;
            width: 100%;
            max-width: 600px;
            max-height: 90vh;
            overflow-y: auto;
        }
        
        .modal-header {
            padding: 1.5rem;
            border-bottom: 2px solid #E2E8F0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .modal-title {
            font-size: 1.5rem;
            font-weight: 700;
            color: #2D3748;
            margin: 0;
        }
        
        .modal-close {
            background: none;
            border: none;
            font-size: 1.5rem;
            color: #718096;
            cursor: pointer;
            padding: 0;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .modal-body {
            padding: 1.5rem;
        }
        
        .alert {
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
        }
        
        .alert-success {
            background: #C6F6D5;
            color: #22543D;
            border: 1px solid #9AE6B4;
        }
        
        .alert-danger {
            background: #FED7D7;
            color: #742A2A;
            border: 1px solid #FC8181;
        }
        
        .checkbox-label {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            cursor: pointer;
        }
        
        .image-preview {
            width: 100%;
            max-width: 200px;
            height: 150px;
            object-fit: cover;
            border-radius: 8px;
            margin-top: 0.5rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <h1><i class="fas fa-utensils"></i> จัดการเมนูอาหาร</h1>
            <div style="display: flex; gap: 0.5rem;">
                <a href="dashboard.php" class="btn btn-outline">
                    <i class="fas fa-arrow-left"></i> กลับ
                </a>
                <button class="btn btn-primary" onclick="openModal('create')">
                    <i class="fas fa-plus"></i> เพิ่มเมนูใหม่
                </button>
            </div>
        </div>

        <!-- Alerts -->
        <?php if ($success): ?>
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?>
        </div>
        <?php endif; ?>

        <?php if ($error): ?>
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?>
        </div>
        <?php endif; ?>

        <!-- Filter Section -->
        <div class="filter-section">
            <form method="GET" action="">
                <div class="filter-grid">
                    <div class="form-group">
                        <label class="form-label">หมวดหมู่</label>
                        <select name="category" class="form-control">
                            <option value="0">ทั้งหมด</option>
                            <?php foreach ($categories as $cat): ?>
                            <option value="<?= $cat['category_id'] ?>" <?= $categoryFilter == $cat['category_id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($cat['name']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">ค้นหา</label>
                        <input type="text" 
                               name="search" 
                               class="form-control" 
                               placeholder="ชื่อเมนู..."
                               value="<?= htmlspecialchars($searchQuery) ?>">
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-search"></i> ค้นหา
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Menu Grid -->
        <div class="menu-grid">
            <?php if (empty($menuItems)): ?>
            <div style="grid-column: 1/-1; text-align: center; padding: 3rem; background: white; border-radius: 12px;">
                <div style="font-size: 4rem; color: #CBD5E0; margin-bottom: 1rem;">
                    <i class="fas fa-inbox"></i>
                </div>
                <h3>ไม่พบเมนูอาหาร</h3>
                <p style="color: #718096;">ลองเปลี่ยนเงื่อนไขการค้นหา หรือเพิ่มเมนูใหม่</p>
            </div>
            <?php else: ?>
            <?php foreach ($menuItems as $item): ?>
            <div class="menu-card">
                <?php if ($item['image_url']): ?>
                    <img src="../assets/images/menu/<?= htmlspecialchars($item['image_url']) ?>" 
                         alt="<?= htmlspecialchars($item['name_th']) ?>" 
                         class="menu-image"
                         onerror="this.style.display='none'">
                <?php else: ?>
                    <div class="menu-image" style="display: flex; align-items: center; justify-content: center; color: #CBD5E0;">
                        <i class="fas fa-image" style="font-size: 3rem;"></i>
                    </div>
                <?php endif; ?>
                
                <div class="menu-content">
                    <div class="menu-category">
                        <i class="fas fa-tag"></i> <?= htmlspecialchars($item['category_name']) ?>
                    </div>
                    
                    <div class="menu-name"><?= htmlspecialchars($item['name_th']) ?></div>
                    
                    <?php if ($item['name_en']): ?>
                    <div style="color: #718096; font-size: 0.9rem; margin-bottom: 0.5rem;">
                        <?= htmlspecialchars($item['name_en']) ?>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ($item['description']): ?>
                    <div class="menu-description"><?= htmlspecialchars($item['description']) ?></div>
                    <?php endif; ?>
                    
                    <div class="menu-price">฿<?= number_format($item['price'], 2) ?></div>
                    
                    <div style="margin-bottom: 1rem;">
                        <span class="menu-status <?= $item['is_available'] ? 'status-available' : 'status-unavailable' ?>">
                            <?= $item['is_available'] ? 'พร้อมขาย' : 'ไม่พร้อมขาย' ?>
                        </span>
                    </div>
                    
                    <div class="menu-actions">
                        <button class="btn btn-warning btn-sm" 
                                onclick='openModal("edit", <?= json_encode($item) ?>)'>
                            <i class="fas fa-edit"></i> แก้ไข
                        </button>
                        <button class="btn btn-danger btn-sm" 
                                onclick="deleteMenu(<?= $item['menu_id'] ?>, '<?= htmlspecialchars($item['name_th']) ?>')">
                            <i class="fas fa-trash"></i> ลบ
                        </button>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- Modal -->
    <div id="menuModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title" id="modalTitle">เพิ่มเมนูใหม่</h2>
                <button class="modal-close" onclick="closeModal()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="modal-body">
                <form method="POST" enctype="multipart/form-data" id="menuForm">
                    <input type="hidden" name="action" id="formAction" value="create">
                    <input type="hidden" name="menu_id" id="menuId">
                    <input type="hidden" name="existing_image" id="existingImage">
                    
                    <div class="form-group">
                        <label class="form-label">หมวดหมู่ *</label>
                        <select name="category_id" id="categoryId" class="form-control" required>
                            <option value="">-- เลือกหมวดหมู่ --</option>
                            <?php foreach ($categories as $cat): ?>
                            <option value="<?= $cat['category_id'] ?>">
                                <?= htmlspecialchars($cat['name']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">ชื่อเมนู (ไทย) *</label>
                        <input type="text" name="name_th" id="nameTh" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">ชื่อเมนู (English)</label>
                        <input type="text" name="name_en" id="nameEn" class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">คำอธิบาย</label>
                        <textarea name="description" id="description" class="form-control" rows="3"></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">ราคาขาย (บาท) *</label>
                        <input type="number" name="price" id="price" class="form-control" step="0.01" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">ต้นทุน (บาท)</label>
                        <input type="number" name="cost" id="cost" class="form-control" step="0.01" value="0">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">รูปภาพ</label>
                        <input type="file" name="image" id="imageFile" class="form-control" accept="image/*" onchange="previewImage(event)">
                        <img id="imagePreview" class="image-preview" style="display: none;">
                    </div>
                    
                    <div class="form-group">
                        <label class="checkbox-label">
                            <input type="checkbox" name="is_available" id="isAvailable" checked>
                            <span>พร้อมขาย</span>
                        </label>
                    </div>
                    
                    <div style="display: flex; gap: 1rem; margin-top: 1.5rem;">
                        <button type="button" class="btn btn-outline" onclick="closeModal()" style="flex: 1;">
                            ยกเลิก
                        </button>
                        <button type="submit" class="btn btn-primary" style="flex: 1;">
                            <i class="fas fa-save"></i> บันทึก
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Delete Form (Hidden) -->
    <form method="POST" id="deleteForm" style="display: none;">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="menu_id" id="deleteMenuId">
    </form>

    <script src="../assets/js/main.js"></script>
    <script>
        function openModal(mode, data = null) {
            const modal = document.getElementById('menuModal');
            const title = document.getElementById('modalTitle');
            const form = document.getElementById('menuForm');
            const action = document.getElementById('formAction');
            
            // Reset form
            form.reset();
            document.getElementById('imagePreview').style.display = 'none';
            
            if (mode === 'create') {
                title.textContent = 'เพิ่มเมนูใหม่';
                action.value = 'create';
                document.getElementById('isAvailable').checked = true;
            } else if (mode === 'edit' && data) {
                title.textContent = 'แก้ไขเมนู';
                action.value = 'update';
                
                document.getElementById('menuId').value = data.menu_id;
                document.getElementById('categoryId').value = data.category_id;
                document.getElementById('nameTh').value = data.name_th;
                document.getElementById('nameEn').value = data.name_en || '';
                document.getElementById('description').value = data.description || '';
                document.getElementById('price').value = data.price;
                document.getElementById('cost').value = data.cost;
                document.getElementById('existingImage').value = data.image_url || '';
                document.getElementById('isAvailable').checked = data.is_available == 1;
                
                // Show existing image
                if (data.image_url) {
                    const preview = document.getElementById('imagePreview');
                    preview.src = '../assets/images/menu/' + data.image_url;
                    preview.style.display = 'block';
                }
            }
            
            modal.classList.add('active');
        }
        
        function closeModal() {
            document.getElementById('menuModal').classList.remove('active');
        }
        
        function previewImage(event) {
            const file = event.target.files[0];
            const preview = document.getElementById('imagePreview');
            
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                }
                reader.readAsDataURL(file);
            }
        }
        
        function deleteMenu(menuId, menuName) {
            if (confirm(`ต้องการลบเมนู "${menuName}" ใช่หรือไม่?`)) {
                document.getElementById('deleteMenuId').value = menuId;
                document.getElementById('deleteForm').submit();
            }
        }
        
        // Close modal when clicking outside
        document.getElementById('menuModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeModal();
            }
        });
    </script>
</body>
</html>
