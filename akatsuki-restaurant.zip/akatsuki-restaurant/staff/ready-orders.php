<?php
/**
 * Ready Orders Page
 * Location: staff/ready-orders.php
 */

require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/staff_auth.php';

$db = getDB();
// Ensure kitchen_queue table exists (migration-safe fallback)
$db->exec("CREATE TABLE IF NOT EXISTS kitchen_queue (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    order_number VARCHAR(50),
    table_number VARCHAR(20),
    total_items INT DEFAULT 0,
    total_price DECIMAL(10,2) DEFAULT 0.00,
    order_date DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    processed TINYINT(1) DEFAULT 0,
    UNIQUE KEY uq_order (order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

// Accept notifications from other staff pages (e.g. orders.php) via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Expect JSON body: { action: 'notify_confirmed', order_id: 123 }
    $input = json_decode(file_get_contents('php://input'), true);

    if (!empty($input['action']) && $input['action'] === 'notify_confirmed' && !empty($input['order_id'])) {
        $orderId = (int)$input['order_id'];

        // Fetch order details
        $stmt = $db->prepare("SELECT o.*, t.table_number, COALESCE(SUM(oi.quantity),0) as total_items
            FROM orders o
            JOIN tables t ON o.table_id = t.table_id
            LEFT JOIN order_items oi ON o.order_id = oi.order_id
            WHERE o.order_id = ?
            GROUP BY o.order_id LIMIT 1");
        $stmt->execute([$orderId]);
        $order = $stmt->fetch();

        if ($order) {
            // Insert into kitchen_queue (avoid duplicates)
            $insert = $db->prepare("INSERT INTO kitchen_queue (order_id, order_number, table_number, total_items, total_price, order_date)
                VALUES (?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE order_number = VALUES(order_number), table_number = VALUES(table_number), total_items = VALUES(total_items), total_price = VALUES(total_price), order_date = VALUES(order_date), processed = 0");

            $insert->execute([
                $order['order_id'],
                $order['order_number'],
                $order['table_number'],
                $order['total_items'] ?? 0,
                $order['total_price'] ?? 0,
                $order['order_date'] ?? null
            ]);

            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'data' => $order]);
            exit;
        }
    }

    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit;
}

// Get ready orders
$stmt = $db->query("
    SELECT o.*, t.table_number, COUNT(oi.order_item_id) as total_items,
           SUM(CASE WHEN oi.status = 'ready' THEN 1 ELSE 0 END) as ready_items
    FROM orders o
    JOIN tables t ON o.table_id = t.table_id
    LEFT JOIN order_items oi ON o.order_id = oi.order_id
    WHERE o.status = 'ready'
    GROUP BY o.order_id
    ORDER BY o.order_date ASC
");
$readyOrders = $stmt->fetchAll();

// Merge any notifications created by orders.php (stored in database/ready_notifications.json)
// Merge unprocessed items from kitchen_queue table (added when orders are confirmed)
$queueStmt = $db->query("SELECT * FROM kitchen_queue WHERE processed = 0 ORDER BY created_at ASC");
$queueItems = $queueStmt->fetchAll();
if (!empty($queueItems)) {
    $existingIds = array_column($readyOrders, 'order_id');
    foreach ($queueItems as $n) {
        $oid = isset($n['order_id']) ? (int)$n['order_id'] : 0;
        if ($oid === 0) continue;
        if (in_array($oid, $existingIds, true)) continue;

        $readyOrders[] = [
            'order_id' => $oid,
            'order_number' => $n['order_number'] ?? ('#' . $oid),
            'table_number' => $n['table_number'] ?? '-',
            'total_items' => $n['total_items'] ?? 0,
            'total_price' => $n['total_price'] ?? 0,
            'order_date' => $n['order_date'] ?? date('Y-m-d H:i:s'),
            'from_notification' => true,
            'status' => 'ready'
        ];
    }
}

$staffInfo = [
    'full_name' => 'Staff',
    'role' => 'staff'
];
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>อาหารพร้อมเสิร์ฟ - Akatsuki Restaurant</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .staff-header {
            background: white;
            box-shadow: var(--shadow);
            padding: 1rem 0;
            margin-bottom: 2rem;
        }
        
        .staff-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .staff-nav-links {
            display: flex;
            gap: 1rem;
            list-style: none;
        }
        
        .staff-nav-link {
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: var(--transition);
            color: var(--text-dark);
        }
        
        .staff-nav-link:hover {
            background: var(--bg-light);
        }
        
        .staff-nav-link.active {
            background: var(--primary-color);
            color: white;
        }
        
        .ready-order-card {
            background: white;
            border-radius: 12px;
            padding: 2rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            margin-bottom: 1.5rem;
            border-left: 5px solid #28A745;
            transition: var(--transition);
            animation: pulse-border 2s infinite;
        }
        
        @keyframes pulse-border {
            0%, 100% {
                border-color: #28A745;
            }
            50% {
                border-color: #20c997;
            }
        }
        
        .ready-order-card:hover {
            transform: translateX(5px);
            box-shadow: 0 6px 30px rgba(40, 167, 69, 0.2);
        }
        
        .ready-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            background: #28A745;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 25px;
            font-weight: 600;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0%, 100% {
                box-shadow: 0 0 0 0 rgba(40, 167, 69, 0.7);
            }
            50% {
                box-shadow: 0 0 0 10px rgba(40, 167, 69, 0);
            }
        }
        
        .table-number-big {
            font-size: 3rem;
            font-weight: 700;
            color: var(--primary-color);
            text-align: center;
            margin-bottom: 0.5rem;
        }
        
        .order-info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin: 1.5rem 0;
        }
        
        .info-item {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 1rem;
            background: var(--bg-light);
            border-radius: 8px;
        }
        
        .info-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.5rem 1rem;
            background: var(--bg-light);
            border-radius: 25px;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
        }
        
        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
        }
        
        .empty-icon {
            font-size: 5rem;
            color: var(--text-light);
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <!-- Staff Header -->
    <header class="staff-header">
        <div class="container">
            <nav class="staff-nav">
                <div class="logo">
                    <i class="fas fa-torii-gate logo-icon"></i>
                    <span>Akatsuki Staff</span>
                </div>
                
                <ul class="staff-nav-links">
                    <li><a href="dashboard.php" class="staff-nav-link"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="orders.php" class="staff-nav-link"><i class="fas fa-receipt"></i> ออเดอร์</a></li>
                    <li><a href="ready-orders.php" class="staff-nav-link active"><i class="fas fa-bell"></i> พร้อมเสิร์ฟ</a></li>
                    <li><a href="tables.php" class="staff-nav-link"><i class="fas fa-chair"></i> โต๊ะ</a></li>
                    <li><a href="payment.php" class="staff-nav-link"><i class="fas fa-cash-register"></i> ชำระเงิน</a></li>
                </ul>
                
                <div class="user-info">
                    <div class="user-avatar">
                        <?= strtoupper(substr($staffInfo['full_name'], 0, 2)) ?>
                    </div>
                    <div>
                        <div style="font-weight: 600;"><?= e($staffInfo['full_name']) ?></div>
                        <div style="font-size: 0.85rem; color: var(--text-light);"><?= e($staffInfo['role']) ?></div>
                    </div>
                    <a href="logout.php" style="color: var(--danger-color); margin-left: 0.5rem;" title="ออกจากระบบ">
                        <i class="fas fa-sign-out-alt"></i>
                    </a>
                </div>
            </nav>
        </div>
    </header>

    <section class="section">
        <div class="container">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                <h1>
                    <i class="fas fa-bell"></i> อาหารพร้อมเสิร์ฟ
                    <?php if (!empty($readyOrders)): ?>
                    <span class="badge badge-success" style="font-size: 1.2rem; margin-left: 0.5rem;">
                        <?= count($readyOrders) ?>
                    </span>
                    <?php endif; ?>
                </h1>
                
                <button class="btn btn-outline" onclick="location.reload()">
                    <i class="fas fa-sync-alt"></i> รีเฟรช
                </button>
            </div>

            <?php if (empty($readyOrders)): ?>
            <!-- Empty State -->
            <div class="card">
                <div class="card-body empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <h2>ไม่มีออเดอร์ที่รอเสิร์ฟ</h2>
                    <p class="text-muted">อาหารทั้งหมดถูกเสิร์ฟแล้วหรือยังไม่พร้อม</p>
                    <div style="margin-top: 2rem;">
                        <a href="orders.php" class="btn btn-primary">
                            <i class="fas fa-receipt"></i> ดูออเดอร์ทั้งหมด
                        </a>
                    </div>
                </div>
            </div>
            <?php else: ?>
            <!-- Ready Orders -->
            <div class="row">
                <?php foreach ($readyOrders as $order): ?>
                <div class="col col-6 col-sm-12" style="margin-bottom: 1.5rem;">
                    <div class="ready-order-card">
                        <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 1.5rem;">
                            <div>
                                <div class="table-number-big">
                                    <i class="fas fa-chair"></i> <?= e($order['table_number']) ?>
                                </div>
                                <div class="ready-badge">
                                    <i class="fas fa-bell"></i>
                                    <span>พร้อมเสิร์ฟ</span>
                                </div>
                            </div>
                            <div style="text-align: right;">
                                <div style="font-size: 0.9rem; color: var(--text-light); margin-bottom: 0.5rem;">
                                    เวลารอ
                                </div>
                                <div style="font-size: 1.5rem; font-weight: 700; color: var(--danger-color);">
                                    <?= timeElapsed($order['order_date']) ?>
                                </div>
                            </div>
                        </div>

                        <div class="order-info-grid">
                            <div class="info-item">
                                <div class="info-icon">
                                    <i class="fas fa-receipt"></i>
                                </div>
                                <div>
                                    <div style="font-size: 0.85rem; color: var(--text-light);">หมายเลข</div>
                                    <div style="font-weight: 600;"><?= e($order['order_number']) ?></div>
                                </div>
                            </div>
                            
                            <div class="info-item">
                                <div class="info-icon" style="background: #28A745;">
                                    <i class="fas fa-utensils"></i>
                                </div>
                                <div>
                                    <div style="font-size: 0.85rem; color: var(--text-light);">รายการ</div>
                                    <div style="font-weight: 600;"><?= $order['total_items'] ?> รายการ</div>
                                </div>
                            </div>
                            
                            <div class="info-item">
                                <div class="info-icon" style="background: #FFC107;">
                                    <i class="fas fa-dollar-sign"></i>
                                </div>
                                <div>
                                    <div style="font-size: 0.85rem; color: var(--text-light);">ยอดรวม</div>
                                    <div style="font-weight: 600;"><?= formatCurrency($order['total_price']) ?></div>
                                </div>
                            </div>
                        </div>

                        <div style="display: flex; gap: 0.75rem; margin-top: 1.5rem;">
                            <button class="btn btn-success btn-block btn-lg" 
                                    onclick="markServed(<?= $order['order_id'] ?>)">
                                <i class="fas fa-check-double"></i> เสิร์ฟแล้ว
                            </button>
                            <a href="order-detail.php?id=<?= $order['order_id'] ?>" 
                               class="btn btn-outline">
                                <i class="fas fa-eye"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- Audio Alert (Optional) -->
    <audio id="alertSound" style="display: none;">
        <source src="../assets/sounds/notification.mp3" type="audio/mpeg">
    </audio>

    <script src="../assets/js/main.js"></script>
    <script>
        let lastOrderCount = <?= count($readyOrders) ?>;

        async function markServed(orderId) {
            const confirmed = await Utils.confirm('ยืนยันว่าเสิร์ฟอาหารแล้ว?');
            if (!confirmed) return;

            Utils.showLoading();

            try {
                const response = await fetch('../api/orders.php', {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'update_status',
                        order_id: orderId,
                        status: 'served'
                    })
                });

                const result = await response.json();

                if (result.success) {
                    Utils.showToast('บันทึกสำเร็จ', 'success');
                    setTimeout(() => location.reload(), 500);
                } else {
                    Utils.showToast(result.message || 'เกิดข้อผิดพลาด', 'error');
                }
            } catch (error) {
                console.error('Error:', error);
                Utils.showToast('เกิดข้อผิดพลาด', 'error');
            } finally {
                Utils.hideLoading();
            }
        }

        // Check for new ready orders every 10 seconds
        setInterval(async () => {
            try {
                const response = await fetch('../api/orders.php?status=ready');
                const result = await response.json();
                
                if (result.success && result.data) {
                    const currentCount = result.data.length;
                    
                    // If new orders appeared
                    if (currentCount > lastOrderCount) {
                        // Play sound
                        const audio = document.getElementById('alertSound');
                        if (audio) audio.play().catch(() => {});
                        
                        // Show notification
                        Utils.showToast('มีอาหารพร้อมเสิร์ฟใหม่!', 'success');
                        
                        // Reload page
                        location.reload();
                    }
                    
                    lastOrderCount = currentCount;
                }
            } catch (error) {
                console.error('Error checking orders:', error);
            }
        }, 10000);

        // Full page reload every 30 seconds as backup
        setTimeout(() => {
            location.reload();
        }, 30000);
    </script>
</body>
</html>
