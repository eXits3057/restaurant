<?php
/**
 * Tables Management
 * Location: staff/tables.php
 */

require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/staff_auth.php';

$db = getDB();

// Get all tables with session info
$stmt = $db->query("
    SELECT t.*, 
           s.start_time,
           s.session_id,
           COALESCE(SUM(o.total_price), 0) as session_total,
           COUNT(DISTINCT o.order_id) as order_count
    FROM tables t
    LEFT JOIN sessions s ON t.current_session_id = s.session_id
    LEFT JOIN orders o ON s.session_id = o.session_id AND o.payment_status = 'unpaid'
    GROUP BY t.table_id
    ORDER BY t.table_number
");
$tables = $stmt->fetchAll();

$staffInfo = [
    'full_name' => 'Staff',
    'role' => 'staff'
];
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>จัดการโต๊ะ - Akatsuki Restaurant</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .staff-header {
            background: white;
            box-shadow: var(--shadow);
            padding: 1rem 0;
            margin-bottom: 2rem;
        }
        
        .staff-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .staff-nav-links {
            display: flex;
            gap: 1rem;
            list-style: none;
        }
        
        .staff-nav-link {
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: var(--transition);
            color: var(--text-dark);
        }
        
        .staff-nav-link:hover {
            background: var(--bg-light);
        }
        
        .staff-nav-link.active {
            background: var(--primary-color);
            color: white;
        }
        
        .table-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 1.5rem;
        }
        
        .table-card {
            background: white;
            border-radius: 16px;
            padding: 2rem;
            box-shadow: var(--shadow);
            transition: var(--transition);
            border: 3px solid #E0E0E0;
        }
        
        .table-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-hover);
        }
        
        .table-card.available {
            border-color: #28A745;
        }
        
        .table-card.occupied {
            border-color: #DC3545;
        }
        
        .table-card.cleaning {
            border-color: #FFC107;
        }
        
        .table-number {
            font-size: 3rem;
            font-weight: 700;
            text-align: center;
            margin-bottom: 0.5rem;
        }
        
        .table-card.available .table-number {
            color: #28A745;
        }
        
        .table-card.occupied .table-number {
            color: #DC3545;
        }
        
        .table-card.cleaning .table-number {
            color: #FFC107;
        }
        
        .table-icon {
            text-align: center;
            font-size: 4rem;
            margin-bottom: 1rem;
            color: var(--text-light);
        }
        
        .table-info {
            text-align: center;
            margin: 1rem 0;
            padding: 1rem;
            background: var(--bg-light);
            border-radius: 8px;
        }
        
        .table-info-item {
            margin: 0.5rem 0;
            font-size: 0.9rem;
        }
        
        .table-actions {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            margin-top: 1rem;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.5rem 1rem;
            background: var(--bg-light);
            border-radius: 25px;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
        }
        
        .summary-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }
        
        .summary-card {
            background: white;
            padding: 1.5rem;
            border-radius: 12px;
            box-shadow: var(--shadow);
            text-align: center;
        }
        
        .summary-number {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }
    </style>
</head>
<body>
    <!-- Staff Header -->
    <header class="staff-header">
        <div class="container">
            <nav class="staff-nav">
                <div class="logo">
                    <i class="fas fa-torii-gate logo-icon"></i>
                    <span>Akatsuki Staff</span>
                </div>
                
                <ul class="staff-nav-links">
                    <li><a href="dashboard.php" class="staff-nav-link"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="orders.php" class="staff-nav-link"><i class="fas fa-receipt"></i> ออเดอร์</a></li>
                    <li><a href="ready-orders.php" class="staff-nav-link"><i class="fas fa-bell"></i> พร้อมเสิร์ฟ</a></li>
                    <li><a href="tables.php" class="staff-nav-link active"><i class="fas fa-chair"></i> โต๊ะ</a></li>
                    <li><a href="payment.php" class="staff-nav-link"><i class="fas fa-cash-register"></i> ชำระเงิน</a></li>
                </ul>
                
                <div class="user-info">
                    <div class="user-avatar">
                        <?= strtoupper(substr($staffInfo['full_name'], 0, 2)) ?>
                    </div>
                    <div>
                        <div style="font-weight: 600;"><?= e($staffInfo['full_name']) ?></div>
                        <div style="font-size: 0.85rem; color: var(--text-light);"><?= e($staffInfo['role']) ?></div>
                    </div>
                    <a href="logout.php" style="color: var(--danger-color); margin-left: 0.5rem;" title="ออกจากระบบ">
                        <i class="fas fa-sign-out-alt"></i>
                    </a>
                </div>
            </nav>
        </div>
    </header>

    <section class="section">
        <div class="container">
            <h1 style="margin-bottom: 2rem;">
                <i class="fas fa-chair"></i> จัดการโต๊ะ
            </h1>

            <!-- Summary -->
            <div class="summary-cards">
                <div class="summary-card">
                    <div class="summary-number" style="color: #28A745;">
                        <?= count(array_filter($tables, fn($t) => $t['status'] === 'available')) ?>
                    </div>
                    <div class="text-muted">โต๊ะว่าง</div>
                </div>
                
                <div class="summary-card">
                    <div class="summary-number" style="color: #DC3545;">
                        <?= count(array_filter($tables, fn($t) => $t['status'] === 'occupied')) ?>
                    </div>
                    <div class="text-muted">โต๊ะไม่ว่าง</div>
                </div>
                
                <div class="summary-card">
                    <div class="summary-number" style="color: #FFC107;">
                        <?= count(array_filter($tables, fn($t) => $t['status'] === 'cleaning')) ?>
                    </div>
                    <div class="text-muted">กำลังเตรียม</div>
                </div>
                
                <div class="summary-card">
                    <div class="summary-number" style="color: var(--primary-color);">
                        <?= count($tables) ?>
                    </div>
                    <div class="text-muted">ทั้งหมด</div>
                </div>
            </div>

            <!-- Tables Grid -->
            <div class="table-grid">
                <?php foreach ($tables as $table): ?>
                <div class="table-card <?= $table['status'] ?>">
                    <div class="table-icon">
                        <i class="fas fa-chair"></i>
                    </div>
                    
                    <div class="table-number">
                        <?= e($table['table_number']) ?>
                    </div>
                    
                    <div style="text-align: center; margin-bottom: 1rem;">
                        <?= getTableStatusBadge($table['status']) ?>
                    </div>
                    
                    <div style="text-align: center; color: var(--text-light); margin-bottom: 1rem;">
                        <i class="fas fa-users"></i> <?= $table['seats'] ?> ที่นั่ง
                    </div>

                    <?php if ($table['status'] === 'occupied'): ?>
                    <div class="table-info">
                        <div class="table-info-item">
                            <strong>เวลาใช้:</strong> <?= timeElapsed($table['start_time']) ?>
                        </div>
                        <div class="table-info-item">
                            <strong>ออเดอร์:</strong> <?= $table['order_count'] ?> รายการ
                        </div>
                        <div class="table-info-item" style="font-size: 1.2rem; color: var(--primary-color);">
                            <strong><?= formatCurrency($table['session_total']) ?></strong>
                        </div>
                    </div>
                    <?php endif; ?>

                    <div class="table-actions">
                        <?php if ($table['status'] === 'available'): ?>
                        <button class="btn btn-primary btn-block" 
                                onclick="openTable(<?= $table['table_id'] ?>)">
                            <i class="fas fa-play"></i> เปิดโต๊ะ
                        </button>
                        
                        <?php elseif ($table['status'] === 'occupied'): ?>
                        <a href="payment.php?table=<?= $table['table_id'] ?>" 
                           class="btn btn-warning btn-block">
                            <i class="fas fa-cash-register"></i> ชำระเงิน
                        </a>
                        <button class="btn btn-outline btn-block" 
                                onclick="viewOrders(<?= $table['table_id'] ?>)">
                            <i class="fas fa-eye"></i> ดูออเดอร์
                        </button>
                        <button class="btn btn-danger btn-block" 
                                onclick="closeTable(<?= $table['table_id'] ?>)">
                            <i class="fas fa-times-circle"></i> ปิดโต๊ะ (บังคับ)
                        </button>
                        
                        <?php elseif ($table['status'] === 'cleaning'): ?>
                        <button class="btn btn-success btn-block" 
                                onclick="markAvailable(<?= $table['table_id'] ?>)">
                            <i class="fas fa-check"></i> เตรียมเสร็จแล้ว
                        </button>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <script src="../assets/js/main.js"></script>
    <script>
        async function openTable(tableId) {
            const confirmed = await Utils.confirm('เปิดโต๊ะนี้?');
            if (!confirmed) return;

            Utils.showLoading();

            try {
                const response = await fetch('../api/tables.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'start_session',
                        table_id: tableId
                    })
                });

                const result = await response.json();

                if (result.success) {
                    Utils.showToast('เปิดโต๊ะสำเร็จ', 'success');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    Utils.showToast(result.message || 'เกิดข้อผิดพลาด', 'error');
                }
            } catch (error) {
                console.error('Error:', error);
                Utils.showToast('เกิดข้อผิดพลาด', 'error');
            } finally {
                Utils.hideLoading();
            }
        }

        async function markAvailable(tableId) {
            const confirmed = await Utils.confirm('ยืนยันว่าเตรียมโต๊ะเสร็จแล้ว?');
            if (!confirmed) return;

            Utils.showLoading();

            try {
                const response = await fetch('../api/tables.php', {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'update_status',
                        table_id: tableId,
                        status: 'available'
                    })
                });

                const result = await response.json();

                if (result.success) {
                    Utils.showToast('อัปเดตสถานะสำเร็จ', 'success');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    Utils.showToast(result.message || 'เกิดข้อผิดพลาด', 'error');
                }
            } catch (error) {
                console.error('Error:', error);
                Utils.showToast('เกิดข้อผิดพลาด', 'error');
            } finally {
                Utils.hideLoading();
            }
        }

        function viewOrders(tableId) {
            window.location.href = `orders.php?table=${tableId}`;
        }

        async function closeTable(tableId) {
            const confirmed = await Utils.confirm(
                'คุณแน่ใจหรือไม่ที่จะปิดโต๊ะนี้?\n\n⚠️ คำเตือน:\n' +
                '• การปิดโต๊ะจะยกเลิกเซสชันปัจจุบัน\n' +
                '• ออเดอร์ที่ยังไม่ชำระจะถูกยกเลิก\n' +
                '• ควรชำระเงินก่อนปิดโต๊ะ\n\n' +
                'ดำเนินการต่อหรือไม่?'
            );
            
            if (!confirmed) return;

            Utils.showLoading();

            try {
                // Use the API's session end action (end_session) via PUT to match server handler
                const response = await fetch('../api/tables.php', {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'end_session',
                        table_id: tableId
                    })
                });

                const result = await response.json();

                if (result.success) {
                    Utils.showToast('ปิดโต๊ะสำเร็จ', 'success');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    Utils.showToast(result.message || 'เกิดข้อผิดพลาด', 'error');
                }
            } catch (error) {
                console.error('Error:', error);
                Utils.showToast('เกิดข้อผิดพลาด', 'error');
            } finally {
                Utils.hideLoading();
            }
        }

        // Auto refresh every 30 seconds
        setInterval(() => {
            location.reload();
        }, 30000);
    </script>
</body>
</html>