<?php
/**
 * Staff Dashboard
 * Location: staff/dashboard.php
 */

require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/staff_auth.php';

$db = getDB();

// Get statistics
$stats = [];

// Today's orders
$stmt = $db->query("
    SELECT COUNT(*) as count, COALESCE(SUM(total_price), 0) as total
    FROM orders 
    WHERE DATE(order_date) = CURDATE()
");
$todayOrders = $stmt->fetch();
$stats['today_orders'] = $todayOrders['count'];
$stats['today_sales'] = $todayOrders['total'];

// Pending orders
$stmt = $db->query("
    SELECT COUNT(*) as count 
    FROM orders 
    WHERE status IN ('pending', 'confirmed', 'cooking')
");
$stats['pending_orders'] = $stmt->fetch()['count'];

// Ready orders
$stmt = $db->query("
    SELECT COUNT(*) as count 
    FROM orders 
    WHERE status = 'ready'
");
$stats['ready_orders'] = $stmt->fetch()['count'];

// Occupied tables
$stmt = $db->query("
    SELECT COUNT(*) as count 
    FROM tables 
    WHERE status = 'occupied'
");
$stats['occupied_tables'] = $stmt->fetch()['count'];

// Available tables
$stmt = $db->query("
    SELECT COUNT(*) as count 
    FROM tables 
    WHERE status = 'available'
");
$stats['available_tables'] = $stmt->fetch()['count'];

// Recent orders
$stmt = $db->query("
    SELECT o.*, t.table_number 
    FROM orders o
    JOIN tables t ON o.table_id = t.table_id
    WHERE DATE(o.order_date) = CURDATE()
    ORDER BY o.order_date DESC
    LIMIT 10
");
$recentOrders = $stmt->fetchAll();

// Active tables
$stmt = $db->query("
    SELECT t.*, s.start_time, COALESCE(SUM(o.total_price), 0) as session_total
    FROM tables t
    LEFT JOIN sessions s ON t.current_session_id = s.session_id
    LEFT JOIN orders o ON s.session_id = o.session_id AND o.payment_status = 'unpaid'
    WHERE t.status = 'occupied'
    GROUP BY t.table_id
    ORDER BY t.table_number
");
$activeTables = $stmt->fetchAll();

// Define default staff info
$staffInfo = [
    'full_name' => 'Staff',
    'role' => 'staff'
];
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Akatsuki Restaurant</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .staff-header {
            background: white;
            box-shadow: var(--shadow);
            padding: 1rem 0;
            margin-bottom: 2rem;
        }
        
        .staff-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .staff-nav-links {
            display: flex;
            gap: 1rem;
            list-style: none;
        }
        
        .staff-nav-link {
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: var(--transition);
            color: var(--text-dark);
        }
        
        .staff-nav-link:hover {
            background: var(--bg-light);
        }
        
        .staff-nav-link.active {
            background: var(--primary-color);
            color: white;
        }
        
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: var(--shadow);
            display: flex;
            align-items: center;
            gap: 1rem;
            transition: var(--transition);
        }
        
        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-hover);
        }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            color: white;
        }
        
        .stat-icon.blue { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .stat-icon.green { background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); }
        .stat-icon.orange { background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); }
        .stat-icon.purple { background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); }
        
        .stat-details {
            flex: 1;
        }
        
        .stat-label {
            color: var(--text-light);
            font-size: 0.9rem;
            margin-bottom: 0.25rem;
        }
        
        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--text-dark);
        }
        
        .quick-action-btn {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.5rem;
            padding: 1.5rem;
            background: white;
            border-radius: 12px;
            box-shadow: var(--shadow);
            transition: var(--transition);
            text-decoration: none;
            color: var(--text-dark);
        }
        
        .quick-action-btn:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-hover);
        }
        
        .quick-action-icon {
            font-size: 2.5rem;
            color: var(--primary-color);
        }
        
        .table-badge {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 12px;
            font-size: 0.85rem;
            font-weight: 600;
        }
        
        .table-badge.occupied {
            background: #FFE5E5;
            color: #DC3545;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.5rem 1rem;
            background: var(--bg-light);
            border-radius: 25px;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
        }
    </style>
</head>
<body>
    <!-- Staff Header -->
    <header class="staff-header">
        <div class="container">
            <nav class="staff-nav">
                <div class="logo">
                    <i class="fas fa-torii-gate logo-icon"></i>
                    <span>Akatsuki Staff</span>
                </div>
                
                <ul class="staff-nav-links">
                    <li><a href="dashboard.php" class="staff-nav-link active"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="orders.php" class="staff-nav-link"><i class="fas fa-receipt"></i> ออเดอร์</a></li>
                    <li><a href="ready-orders.php" class="staff-nav-link"><i class="fas fa-bell"></i> พร้อมเสิร์ฟ</a></li>
                    <li><a href="tables.php" class="staff-nav-link"><i class="fas fa-chair"></i> โต๊ะ</a></li>
                    <li><a href="payment.php" class="staff-nav-link"><i class="fas fa-cash-register"></i> ชำระเงิน</a></li>
                    <li><a href="../index.php" class="nav-link ">กลับไปยังหน้าลูกค้า</a></li>
                </ul>
                
                <div class="user-info">
                    <div class="user-avatar">
                        <?= strtoupper(substr($staffInfo['full_name'], 0, 2)) ?>
                    </div>
                    <div>
                        <div style="font-weight: 600;"><?= e($staffInfo['full_name']) ?></div>
                        <div style="font-size: 0.85rem; color: var(--text-light);"><?= e($staffInfo['role']) ?></div>
                    </div>
                </div>
            </nav>
        </div>
    </header>

    <section class="section">
        <div class="container">
            <h1 style="margin-bottom: 2rem;">
                <i class="fas fa-chart-line"></i> Dashboard
            </h1>

            <!-- Statistics -->
            <div class="row" style="margin-bottom: 3rem;">
                <div class="col col-3 col-sm-6" style="margin-bottom: 1.5rem;">
                    <div class="stat-card">
                        <div class="stat-icon blue">
                            <i class="fas fa-receipt"></i>
                        </div>
                        <div class="stat-details">
                            <div class="stat-label">ออเดอร์วันนี้</div>
                            <div class="stat-value"><?= $stats['today_orders'] ?></div>
                        </div>
                    </div>
                </div>
                
                <div class="col col-3 col-sm-6" style="margin-bottom: 1.5rem;">
                    <div class="stat-card">
                        <div class="stat-icon green">
                            <i class="fas fa-dollar-sign"></i>
                        </div>
                        <div class="stat-details">
                            <div class="stat-label">ยอดขายวันนี้</div>
                            <div class="stat-value" style="font-size: 1.5rem;"><?= formatCurrency($stats['today_sales']) ?></div>
                        </div>
                    </div>
                </div>
                
                <div class="col col-3 col-sm-6" style="margin-bottom: 1.5rem;">
                    <div class="stat-card">
                        <div class="stat-icon orange">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div class="stat-details">
                            <div class="stat-label">รอดำเนินการ</div>
                            <div class="stat-value"><?= $stats['pending_orders'] ?></div>
                        </div>
                    </div>
                </div>
                
                <div class="col col-3 col-sm-6" style="margin-bottom: 1.5rem;">
                    <div class="stat-card">
                        <div class="stat-icon purple">
                            <i class="fas fa-bell"></i>
                        </div>
                        <div class="stat-details">
                            <div class="stat-label">พร้อมเสิร์ฟ</div>
                            <div class="stat-value"><?= $stats['ready_orders'] ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <h2 style="margin-bottom: 1.5rem;">
                <i class="fas fa-bolt"></i> เมนูด่วน
            </h2>
            
            <div class="row" style="margin-bottom: 3rem;">
                <div class="col col-3 col-sm-6 col-md-4" style="margin-bottom: 1.5rem;">
                    <a href="orders.php" class="quick-action-btn">
                        <div class="quick-action-icon"><i class="fas fa-list"></i></div>
                        <div>จัดการออเดอร์</div>
                    </a>
                </div>
                
                <div class="col col-3 col-sm-6 col-md-4" style="margin-bottom: 1.5rem;">
                    <a href="ready-orders.php" class="quick-action-btn">
                        <div class="quick-action-icon"><i class="fas fa-bell"></i></div>
                        <div>อาหารพร้อมเสิร์ฟ</div>
                    </a>
                </div>
                
                <div class="col col-3 col-sm-6 col-md-4" style="margin-bottom: 1.5rem;">
                    <a href="tables.php" class="quick-action-btn">
                        <div class="quick-action-icon"><i class="fas fa-chair"></i></div>
                        <div>จัดการโต๊ะ</div>
                    </a>
                </div>
                
                <div class="col col-3 col-sm-6 col-md-4" style="margin-bottom: 1.5rem;">
                    <a href="payment.php" class="quick-action-btn">
                        <div class="quick-action-icon"><i class="fas fa-cash-register"></i></div>
                        <div>ชำระเงิน</div>
                    </a>
                </div>
                
                <div class="col col-3 col-sm-6 col-md-4" style="margin-bottom: 1.5rem;">
                    <a href="menu-management.php" class="quick-action-btn">
                        <div class="quick-action-icon"><i class="fas fa-utensils"></i></div>
                        <div>จัดการเมนูอาหาร</div>
                    </a>
                </div>
            </div>

            <div class="row">
                <!-- Active Tables -->
                <div class="col col-6 col-sm-12" style="margin-bottom: 2rem;">
                    <div class="card">
                        <div class="card-body">
                            <h3 style="margin-bottom: 1.5rem;">
                                <i class="fas fa-chair"></i> โต๊ะที่กำลังใช้งาน
                                <span class="badge badge-danger" style="margin-left: 0.5rem;"><?= $stats['occupied_tables'] ?></span>
                            </h3>
                            
                            <?php if (empty($activeTables)): ?>
                            <p class="text-muted text-center" style="padding: 2rem;">ไม่มีโต๊ะที่กำลังใช้งาน</p>
                            <?php else: ?>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>โต๊ะ</th>
                                            <th>เวลาเริ่ม</th>
                                            <th>ยอดรวม</th>
                                            <th>จัดการ</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($activeTables as $table): ?>
                                        <tr>
                                            <td>
                                                <strong><?= e($table['table_number']) ?></strong>
                                                <span class="table-badge occupied">ใช้งาน</span>
                                            </td>
                                            <td><?= $table['start_time'] ? timeElapsed($table['start_time']) : '-' ?></td>
                                            <td><strong><?= formatCurrency($table['session_total']) ?></strong></td>
                                            <td>
                                                <a href="payment.php?table=<?= $table['table_id'] ?>" class="btn btn-sm btn-primary">
                                                    <i class="fas fa-cash-register"></i> ชำระเงิน
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Recent Orders -->
                <div class="col col-6 col-sm-12" style="margin-bottom: 2rem;">
                    <div class="card">
                        <div class="card-body">
                            <h3 style="margin-bottom: 1.5rem;">
                                <i class="fas fa-history"></i> ออเดอร์ล่าสุด
                            </h3>
                            
                            <?php if (empty($recentOrders)): ?>
                            <p class="text-muted text-center" style="padding: 2rem;">ยังไม่มีออเดอร์วันนี้</p>
                            <?php else: ?>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>หมายเลข</th>
                                            <th>โต๊ะ</th>
                                            <th>ยอดรวม</th>
                                            <th>สถานะ</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($recentOrders as $order): ?>
                                        <tr>
                                            <td><strong><?= e($order['order_number']) ?></strong></td>
                                            <td><?= e($order['table_number']) ?></td>
                                            <td><?= formatCurrency($order['total_price']) ?></td>
                                            <td><?= getStatusBadge($order['status']) ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php endif; ?>
                            
                            <div style="text-align: center; margin-top: 1rem;">
                                <a href="orders.php" class="btn btn-outline">
                                    ดูทั้งหมด <i class="fas fa-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="../assets/js/main.js"></script>
    <script>
        // Auto refresh every 30 seconds
        setTimeout(() => {
            location.reload();
        }, 30000);
    </script>
</body>
</html>