<?php
/**
 * Helper Functions
 * Akatsuki Restaurant Management System
 */

/**
 * Sanitize input data
 */
function sanitize($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

/**
 * Generate order number
 */
function generateOrderNumber() {
    return 'ORD' . date('Ymd') . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
}

/**
 * Format currency (Thai Baht)
 */
function formatCurrency($amount) {
    return '฿' . number_format($amount, 2);
}

/**
 * Format date time (Thai format)
 */
function formatDateTime($datetime) {
    return date('d/m/Y H:i', strtotime($datetime));
}

/**
 * Format date only
 */
function formatDate($date) {
    return date('d/m/Y', strtotime($date));
}

/**
 * Format time only
 */
function formatTime($time) {
    return date('H:i', strtotime($time));
}

/**
 * Calculate time elapsed
 */
function timeElapsed($datetime) {
    $now = new DateTime();
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);
    
    if ($diff->d > 0) {
        return $diff->d . ' วัน';
    } elseif ($diff->h > 0) {
        return $diff->h . ' ชม.';
    } elseif ($diff->i > 0) {
        return $diff->i . ' นาที';
    } else {
        return 'เมื่อสักครู่';
    }
}

/**
 * Check if user is logged in
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Check user role
 */
function hasRole($role) {
    return isset($_SESSION['role']) && $_SESSION['role'] === $role;
}

/**
 * Redirect to page
 */
function redirect($url) {
    header("Location: " . SITE_URL . "/" . $url);
    exit();
}

/**
 * Get current user ID
 */
function getCurrentUserId() {
    return isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
}

/**
 * Get current user name
 */
function getCurrentUserName() {
    return isset($_SESSION['full_name']) ? $_SESSION['full_name'] : 'Guest';
}

/**
 * Get status badge HTML
 */
function getStatusBadge($status) {
    $badges = [
        'pending' => '<span class="badge bg-warning">รอยืนยัน</span>',
        'confirmed' => '<span class="badge bg-info">ยืนยันแล้ว</span>',
        'cooking' => '<span class="badge bg-primary">กำลังทำ</span>',
        'ready' => '<span class="badge bg-success">พร้อมเสร็ฟ</span>',
        'served' => '<span class="badge bg-secondary">เสร็ฟแล้ว</span>',
        'completed' => '<span class="badge bg-dark">เสร็จสิ้น</span>',
        'cancelled' => '<span class="badge bg-danger">ยกเลิก</span>',
        'rejected' => '<span class="badge bg-danger">ปฏิเสธ</span>',
    ];
    
    return isset($badges[$status]) ? $badges[$status] : '<span class="badge bg-secondary">' . $status . '</span>';
}

/**
 * Get table status badge HTML
 */
function getTableStatusBadge($status) {
    $badges = [
        'available' => '<span class="badge bg-success">ว่าง</span>',
        'occupied' => '<span class="badge bg-danger">ไม่ว่าง</span>',
        'cleaning' => '<span class="badge bg-warning">ทำความสะอาด</span>',
    ];
    
    return isset($badges[$status]) ? $badges[$status] : '<span class="badge bg-secondary">' . $status . '</span>';
}

/**
 * Get payment status badge HTML
 */
function getPaymentStatusBadge($status) {
    $badges = [
        'unpaid' => '<span class="badge bg-warning">ยังไม่ชำระ</span>',
        'paid' => '<span class="badge bg-success">ชำระแล้ว</span>',
    ];
    
    return isset($badges[$status]) ? $badges[$status] : '<span class="badge bg-secondary">' . $status . '</span>';
}

/**
 * Upload image file
 */
function uploadImage($file, $uploadDir = UPLOAD_DIR) {
    if (!isset($file['error']) || is_array($file['error'])) {
        return ['success' => false, 'message' => 'Invalid parameters.'];
    }
    
    // Check upload errors
    switch ($file['error']) {
        case UPLOAD_ERR_OK:
            break;
        case UPLOAD_ERR_NO_FILE:
            return ['success' => false, 'message' => 'No file sent.'];
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            return ['success' => false, 'message' => 'Exceeded filesize limit.'];
        default:
            return ['success' => false, 'message' => 'Unknown errors.'];
    }
    
    // Check file size
    if ($file['size'] > MAX_FILE_SIZE) {
        return ['success' => false, 'message' => 'Exceeded filesize limit.'];
    }
    
    // Check file extension
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ALLOWED_EXTENSIONS)) {
        return ['success' => false, 'message' => 'Invalid file format.'];
    }
    
    // Generate unique filename
    $filename = uniqid() . '.' . $ext;
    $destination = $uploadDir . $filename;
    
    // Create directory if not exists
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    
    // Move uploaded file
    if (move_uploaded_file($file['tmp_name'], $destination)) {
        return ['success' => true, 'filename' => $filename, 'path' => $destination];
    }
    
    return ['success' => false, 'message' => 'Failed to move uploaded file.'];
}

/**
 * Send JSON response
 */
function jsonResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit();
}

/**
 * Hash password
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT);
}

/**
 * Verify password
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Generate random string
 */
function generateRandomString($length = 10) {
    return bin2hex(random_bytes($length / 2));
}

/**
 * Calculate profit margin percentage
 */
function calculateProfitMargin($price, $cost) {
    if ($price <= 0) return 0;
    return round((($price - $cost) / $price) * 100, 2);
}

/**
 * Get Thai month name
 */
function getThaiMonth($month) {
    $months = [
        1 => 'มกราคม', 2 => 'กุมภาพันธ์', 3 => 'มีนาคม',
        4 => 'เมษายน', 5 => 'พฤษภาคม', 6 => 'มิถุนายน',
        7 => 'กรกฎาคม', 8 => 'สิงหาคม', 9 => 'กันยายน',
        10 => 'ตุลาคม', 11 => 'พฤศจิกายน', 12 => 'ธันวาคม'
    ];
    return isset($months[$month]) ? $months[$month] : '';
}

/**
 * Escape output
 */
function e($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}
?>
