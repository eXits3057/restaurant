<?php
/**
 * Authentication Helper
 * Akatsuki Restaurant Management System
 */

/**
 * Start session if not already started
 */
function initSession() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

/**
 * Login user
 */
function login($username, $password) {
    $db = getDB();
    
    try {
        $stmt = $db->prepare("SELECT * FROM users WHERE username = ? AND status = 'active' LIMIT 1");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        
        if (!$user) {
            return ['success' => false, 'message' => 'ไม่พบชื่อผู้ใช้นี้ในระบบ'];
        }
        
        // Debug password verification
        $isValid = verifyPassword($password, $user['password']);
        if (!$isValid) {
            return ['success' => false, 'message' => 'รหัสผ่านไม่ถูกต้อง'];
        }
        
        if ($isValid) {
            initSession();
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['login_time'] = time();
            
            return ['success' => true, 'role' => $user['role']];
        }
        
        return ['success' => false, 'message' => 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง'];
    } catch (PDOException $e) {
        return ['success' => false, 'message' => 'เกิดข้อผิดพลาด: ' . $e->getMessage()];
    }
}

/**
 * Logout user
 */
function logout() {
    initSession();
    $_SESSION = [];
    session_destroy();
}

/**
 * Check if session is valid
 */
function isSessionValid() {
    initSession();
    if (!isLoggedIn()) {
        return false;
    }
    
    // Check session timeout
    if (isset($_SESSION['login_time'])) {
        $elapsed = time() - $_SESSION['login_time'];
        if ($elapsed > SESSION_LIFETIME) {
            logout();
            return false;
        }
        $_SESSION['login_time'] = time(); // Refresh session time
    }
    
    return true;
}

/**
 * Require login
 */
function requireLogin() {
    if (!isSessionValid()) {
        redirect('staff/login.php');
    }
}

/**
 * Require specific role
 */
function requireRole($requiredRole) {
    requireLogin();
    
    if (!hasRole($requiredRole)) {
        http_response_code(403);
        die('Access denied: You do not have permission to access this page.');
    }
}

/**
 * Require admin role
 */
function requireAdmin() {
    requireRole('admin');
}

/**
 * Require staff role
 */
function requireStaff() {
    requireLogin();
    if (!hasRole('staff') && !hasRole('admin')) {
        http_response_code(403);
        die('Access denied: Staff access required.');
    }
}

/**
 * Require chef role
 */
function requireChef() {
    requireLogin();
    if (!hasRole('chef') && !hasRole('admin')) {
        http_response_code(403);
        die('Access denied: Chef access required.');
    }
}
?>
