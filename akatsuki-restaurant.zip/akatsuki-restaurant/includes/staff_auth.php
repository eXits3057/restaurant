<?php
// This file handles staff-only routes that don't require authentication
session_start();

// Set default staff session for direct access
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 1; // Use a default staff account ID
    $_SESSION['role'] = 'staff';
    $_SESSION['username'] = 'staff';
}

// Function to check if accessing from allowed IP range (optional security measure)
function isAllowedIP() {
    // Add your restaurant's IP range here
    $allowedIPs = array(
        '127.0.0.1',     // localhost
        '::1',           // localhost IPv6
        '192.168.1.',    // local network (example)
    );
    
    foreach ($allowedIPs as $ip) {
        if (str_starts_with($_SERVER['REMOTE_ADDR'], $ip)) {
            return true;
        }
    }
    
    return false;
}

// Redirect to error page if accessing from unauthorized IP (optional)
if (!isAllowedIP()) {
    header('Location: ../error.php?message=Unauthorized access');
    exit;
}
?>