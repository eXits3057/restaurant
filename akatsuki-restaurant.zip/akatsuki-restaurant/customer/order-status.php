<?php
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
initSession();

// Check if order ID is provided
$orderId = isset($_GET['order_id']) ? (int)$_GET['order_id'] : null;

if (!$orderId) {
    redirect('customer/select-table.php');
}

// Get order details
$db = getDB();
$stmt = $db->prepare("
    SELECT o.*, t.table_number, t.seats
    FROM orders o
    JOIN tables t ON o.table_id = t.table_id
    WHERE o.order_id = ?
");
$stmt->execute([$orderId]);
$order = $stmt->fetch();

if (!$order) {
    redirect('customer/select-table.php');
}

// Get order items
$stmt = $db->prepare("
    SELECT oi.*, m.name_th, m.image_url, c.name as category_name
    FROM order_items oi
    JOIN menu_items m ON oi.menu_id = m.menu_id
    JOIN categories c ON m.category_id = c.category_id
    WHERE oi.order_id = ?
    ORDER BY oi.order_item_id
");
$stmt->execute([$orderId]);
$orderItems = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>สถานะออเดอร์ - Akatsuki Restaurant</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .order-header {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            color: white;
            padding: 2rem;
            border-radius: 12px;
            margin-bottom: 2rem;
        }
        
        .order-number {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }
        
        .status-timeline {
            display: flex;
            justify-content: space-between;
            padding: 2rem 0;
            position: relative;
            margin: 3rem 0;
        }
        
        .status-timeline::before {
            content: '';
            position: absolute;
            top: 30px;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--border-color);
            z-index: 0;
        }
        
        .timeline-progress {
            position: absolute;
            top: 30px;
            left: 0;
            height: 4px;
            background: var(--primary-color);
            z-index: 1;
            transition: width 0.5s ease;
        }
        
        .status-step {
            display: flex;
            flex-direction: column;
            align-items: center;
            position: relative;
            z-index: 2;
            flex: 1;
        }
        
        .status-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: white;
            border: 4px solid var(--border-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: var(--text-light);
            transition: var(--transition);
            margin-bottom: 1rem;
        }
        
        .status-step.active .status-icon {
            background: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
            animation: pulse 2s infinite;
        }
        
        .status-step.completed .status-icon {
            background: var(--success-color);
            border-color: var(--success-color);
            color: white;
        }
        
        @keyframes pulse {
            0%, 100% {
                box-shadow: 0 0 0 0 rgba(230, 0, 18, 0.4);
            }
            50% {
                box-shadow: 0 0 0 15px rgba(230, 0, 18, 0);
            }
        }
        
        .status-label {
            text-align: center;
            font-weight: 600;
            color: var(--text-light);
        }
        
        .status-step.active .status-label,
        .status-step.completed .status-label {
            color: var(--text-dark);
        }
        
        .order-item-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            box-shadow: var(--shadow);
            display: flex;
            gap: 1.5rem;
            align-items: center;
        }
        
        .order-item-image {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 8px;
        }
        
        .order-item-details {
            flex: 1;
        }
        
        .order-item-status {
            text-align: right;
        }
        
        .summary-card {
            background: white;
            border-radius: 12px;
            padding: 2rem;
            box-shadow: var(--shadow);
        }
        
        .summary-row {
            display: flex;
            justify-content: space-between;
            padding: 0.75rem 0;
            border-bottom: 1px solid var(--border-color);
        }
        
        .summary-row:last-child {
            border-bottom: none;
            font-size: 1.3rem;
            font-weight: 700;
            color: var(--primary-color);
            padding-top: 1rem;
        }
        
        .refresh-btn {
            position: fixed;
            bottom: 2rem;
            right: 2rem;
            width: 70px;
            height: 70px;
            border-radius: 50%;
            background: var(--primary-color);
            color: white;
            border: none;
            box-shadow: 0 4px 20px rgba(230, 0, 18, 0.4);
            cursor: pointer;
            font-size: 1.8rem;
            transition: var(--transition);
            z-index: 1000;
        }
        
        .refresh-btn:hover {
            transform: rotate(180deg) scale(1.1);
        }
    </style>
</head>
<body>
    <header class="header">
        <nav class="navbar">
            <div class="logo">
                <i class="fas fa-torii-gate logo-icon"></i>
                <span>Akatsuki Restaurant</span>
            </div>
            <ul class="nav-menu">
                <li><a href="../index.php" class="nav-link"><i class="fas fa-home"></i> หน้าแรก</a></li>
                <li><a href="menu.php?table=<?= $order['table_id'] ?>" class="nav-link"><i class="fas fa-book-open"></i> เมนู</a></li>
                <li><a href="order-status.php?order_id=<?= $orderId ?>" class="nav-link active"><i class="fas fa-receipt"></i> สถานะออเดอร์</a></li>
            </ul>
        </nav>
    </header>

    <section class="section">
        <div class="container">
            <!-- Order Header -->
            <div class="order-header">
                <div class="order-number">
                    <i class="fas fa-receipt"></i> <?= e($order['order_number']) ?>
                </div>
                <div style="opacity: 0.9;">
                    <i class="fas fa-chair"></i> โต๊ะ <?= e($order['table_number']) ?> 
                    | <i class="fas fa-clock"></i> <?= formatDateTime($order['order_date']) ?>
                </div>
            </div>

            <!-- Status Timeline -->
            <div class="status-timeline">
                <div class="timeline-progress" id="timelineProgress"></div>
                
                <div class="status-step <?= in_array($order['status'], ['pending', 'confirmed', 'cooking', 'ready', 'served', 'completed']) ? 'completed' : '' ?>">
                    <div class="status-icon">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="status-label">รับออเดอร์</div>
                </div>
                
                <div class="status-step <?= $order['status'] === 'confirmed' ? 'active' : (in_array($order['status'], ['cooking', 'ready', 'served', 'completed']) ? 'completed' : '') ?>">
                    <div class="status-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="status-label">ยืนยันแล้ว</div>
                </div>
                
                <div class="status-step <?= $order['status'] === 'cooking' ? 'active' : (in_array($order['status'], ['ready', 'served', 'completed']) ? 'completed' : '') ?>">
                    <div class="status-icon">
                        <i class="fas fa-fire"></i>
                    </div>
                    <div class="status-label">กำลังทำ</div>
                </div>
                
                <div class="status-step <?= $order['status'] === 'ready' ? 'active' : (in_array($order['status'], ['served', 'completed']) ? 'completed' : '') ?>">
                    <div class="status-icon">
                        <i class="fas fa-bell"></i>
                    </div>
                    <div class="status-label">พร้อมเสิร์ฟ</div>
                </div>
                
                <div class="status-step <?= in_array($order['status'], ['served', 'completed']) ? 'completed' : '' ?>">
                    <div class="status-icon">
                        <i class="fas fa-check-double"></i>
                    </div>
                    <div class="status-label">เสิร์ฟแล้ว</div>
                </div>
            </div>

            <!-- Current Status Alert -->
            <div class="alert <?= $order['status'] === 'ready' ? 'alert-success' : 'alert-info' ?> text-center" style="font-size: 1.2rem;">
                <strong>
                    <?php
                    $statusMessages = [
                        'pending' => '<i class="fas fa-clock"></i> รอยืนยันจากครัว',
                        'confirmed' => '<i class="fas fa-check"></i> ครัวยืนยันออเดอร์แล้ว',
                        'cooking' => '<i class="fas fa-fire"></i> กำลังปรุงอาหารของคุณ',
                        'ready' => '<i class="fas fa-bell"></i> อาหารพร้อมเสิร์ฟแล้ว!',
                        'served' => '<i class="fas fa-utensils"></i> เสิร์ฟอาหารแล้ว',
                        'completed' => '<i class="fas fa-check-circle"></i> เสร็จสิ้น',
                        'cancelled' => '<i class="fas fa-times"></i> ยกเลิกออเดอร์'
                    ];
                    echo $statusMessages[$order['status']] ?? 'กำลังดำเนินการ';
                    ?>
                </strong>
            </div>

            <!-- Order Items -->
            <div class="row" style="margin-top: 3rem;">
                <div class="col col-8 col-sm-12">
                    <h3 style="margin-bottom: 1.5rem;">รายการอาหาร</h3>
                    
                    <?php foreach ($orderItems as $item): ?>
                    <div class="order-item-card">
                        <img src="../assets/images/menu/<?= e($item['image_url']) ?>" 
                             alt="<?= e($item['name_th']) ?>" 
                             class="order-item-image"
                             onerror="this.src='https://via.placeholder.com/80?text=<?= urlencode($item['name_th']) ?>'">
                        
                        <div class="order-item-details">
                            <h4 style="margin-bottom: 0.25rem;"><?= e($item['name_th']) ?></h4>
                            <div class="text-muted" style="font-size: 0.9rem; margin-bottom: 0.5rem;">
                                <?= e($item['category_name']) ?>
                            </div>
                            <div style="color: var(--primary-color); font-weight: 700;">
                                <?= formatCurrency($item['price']) ?> × <?= $item['quantity'] ?> = 
                                <?= formatCurrency($item['price'] * $item['quantity']) ?>
                            </div>
                            <?php if ($item['special_request']): ?>
                            <div style="margin-top: 0.5rem;">
                                <small class="text-muted">
                                    <i class="fas fa-comment"></i> <?= e($item['special_request']) ?>
                                </small>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="order-item-status">
                            <?= getStatusBadge($item['status']) ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <div class="col col-4 col-sm-12">
                    <!-- Summary -->
                    <div class="summary-card">
                        <h3 style="margin-bottom: 1.5rem;">สรุปรายการ</h3>
                        
                        <div class="summary-row">
                            <span>หมายเลขออเดอร์</span>
                            <span><?= e($order['order_number']) ?></span>
                        </div>
                        
                        <div class="summary-row">
                            <span>โต๊ะ</span>
                            <span><?= e($order['table_number']) ?></span>
                        </div>
                        
                        <div class="summary-row">
                            <span>สถานะ</span>
                            <span><?= getStatusBadge($order['status']) ?></span>
                        </div>
                        
                        <div class="summary-row">
                            <span>การชำระเงิน</span>
                            <span><?= getPaymentStatusBadge($order['payment_status']) ?></span>
                        </div>
                        
                        <div class="summary-row">
                            <span>ยอดรวม</span>
                            <span><?= formatCurrency($order['total_price']) ?></span>
                        </div>
                        
                        <?php if ($order['status'] === 'ready'): ?>
                        <div class="alert alert-success mt-3">
                            <i class="fas fa-bell"></i> อาหารพร้อมเสิร์ฟแล้ว!<br>
                            กรุณาแจ้งพนักงาน
                        </div>
                        <?php endif; ?>
                        
                        <div style="margin-top: 2rem;">
                            <a href="menu.php?table=<?= $order['table_id'] ?>" class="btn btn-primary btn-block">
                                <i class="fas fa-plus"></i> สั่งเพิ่ม
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Refresh Button -->
    <button class="refresh-btn" onclick="location.reload()" title="รีเฟรชหน้า">
        <i class="fas fa-sync-alt"></i>
    </button>

    <script src="../assets/js/main.js"></script>
    <script>
        // Update timeline progress
        function updateTimelineProgress() {
            const status = '<?= $order['status'] ?>';
            const statuses = ['pending', 'confirmed', 'cooking', 'ready', 'served'];
            const currentIndex = statuses.indexOf(status);
            const progress = currentIndex >= 0 ? ((currentIndex) / (statuses.length - 1)) * 100 : 0;
            
            document.getElementById('timelineProgress').style.width = progress + '%';
        }

        // Auto refresh every 30 seconds
        let autoRefreshInterval;
        
        function startAutoRefresh() {
            autoRefreshInterval = setInterval(() => {
                location.reload();
            }, 30000); // 30 seconds
        }

        // Stop auto refresh on visibility change
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                clearInterval(autoRefreshInterval);
            } else {
                startAutoRefresh();
            }
        });

        // Initialize
        document.addEventListener('DOMContentLoaded', () => {
            updateTimelineProgress();
            
            // Start auto refresh if order is not completed
            const status = '<?= $order['status'] ?>';
            if (!['completed', 'cancelled'].includes(status)) {
                startAutoRefresh();
            }

            // Show notification if order is ready
            if (status === 'ready') {
                Utils.showToast('อาหารพร้อมเสิร์ฟแล้ว!', 'success');
            }
        });
    </script>
</body>
</html>
