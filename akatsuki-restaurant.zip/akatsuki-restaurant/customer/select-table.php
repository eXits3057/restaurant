<?php
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
initSession();

// Clear any existing cart and session data
unset($_SESSION['cart']);
unset($_SESSION['table_id']);
unset($_SESSION['table_number']);

// Get all tables
$db = getDB();
$stmt = $db->query("SELECT * FROM tables ORDER BY table_number");
$tables = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เลือกโต๊ะ - Akatsuki Restaurant</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .table-card {
            border: 3px solid #E0E0E0;
            transition: all 0.3s ease;
        }
        
        .table-card.available {
            border-color: #28A745;
        }
        
        .table-card.available:hover {
            transform: translateY(-8px);
            box-shadow: 0 12px 28px rgba(40, 167, 69, 0.3);
            border-color: #218838;
        }
        
        .table-card.occupied {
            border-color: #DC3545;
            opacity: 0.6;
            cursor: not-allowed;
        }
        
        .table-card.cleaning {
            border-color: #FFC107;
            opacity: 0.7;
            cursor: not-allowed;
        }
        
        .table-icon {
            font-size: 4rem;
            margin-bottom: 1rem;
            color: var(--text-dark);
        }
        
        .table-card.available .table-icon {
            color: #28A745;
        }
        
        .table-card.occupied .table-icon {
            color: #DC3545;
        }
        
        .table-card.cleaning .table-icon {
            color: #FFC107;
        }
    </style>
</head>
<body>
    <header class="header">
        <nav class="navbar">
            <div class="logo">
                <i class="fas fa-torii-gate logo-icon"></i>
                <span>Akatsuki Restaurant</span>
            </div>
            <ul class="nav-menu">
                <li><a href="../index.php" class="nav-link"><i class="fas fa-home"></i> หน้าแรก</a></li>
                <li><a href="select-table.php" class="nav-link active"><i class="fas fa-chair"></i> เลือกโต๊ะ</a></li>
            </ul>
        </nav>
    </header>

    <section class="section">
        <div class="container">
            <h1 class="section-title">เลือกโต๊ะของคุณ</h1>
            <p class="text-center text-muted mb-4">กรุณาเลือกโต๊ะที่ว่าง เพื่อเริ่มสั่งอาหาร</p>

            <!-- Legend -->
            <div style="text-align: center; margin-bottom: 3rem;">
                <span class="badge badge-success" style="margin: 0 0.5rem; padding: 0.5rem 1rem;">
                    <i class="fas fa-check-circle"></i> ว่าง
                </span>
                <span class="badge badge-danger" style="margin: 0 0.5rem; padding: 0.5rem 1rem;">
                    <i class="fas fa-times-circle"></i> ไม่ว่าง
                </span>
                <span class="badge badge-warning" style="margin: 0 0.5rem; padding: 0.5rem 1rem;">
                    <i class="fas fa-clock"></i> กำลังเตรียม
                </span>
            </div>

            <div class="row" style="margin-top: 3rem;">
                <?php foreach ($tables as $table): ?>
                <div class="col col-3 col-sm-6" style="margin-bottom: 2rem;">
                    <div class="card table-card <?= $table['status'] ?>" 
                         data-table-id="<?= $table['table_id'] ?>"
                         data-table-number="<?= e($table['table_number']) ?>"
                         data-status="<?= $table['status'] ?>"
                         style="cursor: pointer;">
                        <div class="card-body text-center" style="padding: 2.5rem 2rem;">
                            <div class="table-icon">
                                <i class="fas fa-chair"></i>
                            </div>
                            <h3 class="card-title" style="font-size: 1.8rem; margin-bottom: 0.5rem;">
                                <?= e($table['table_number']) ?>
                            </h3>
                            <p class="text-muted" style="margin-bottom: 1rem;">
                                <i class="fas fa-users"></i> <?= $table['seats'] ?> ที่นั่ง
                            </p>
                            <div style="margin-top: 1rem;">
                                <?= getTableStatusBadge($table['status']) ?>
                            </div>
                            <?php if ($table['status'] === 'available'): ?>
                            <button class="btn btn-primary btn-block mt-3 select-table-btn">
                                <i class="fas fa-check"></i> เลือกโต๊ะนี้
                            </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <?php if (empty($tables)): ?>
            <div class="alert alert-info text-center">
                <i class="fas fa-info-circle"></i> ไม่มีข้อมูลโต๊ะในระบบ กรุณาติดต่อพนักงาน
            </div>
            <?php endif; ?>
        </div>
    </section>

    <script src="../assets/js/main.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Handle table selection
            document.querySelectorAll('.select-table-btn').forEach(btn => {
                btn.addEventListener('click', async (e) => {
                    e.stopPropagation();
                    const card = e.target.closest('.table-card');
                    const tableId = card.dataset.tableId;
                    const tableNumber = card.dataset.tableNumber;
                    const status = card.dataset.status;

                    if (status !== 'available') {
                        Utils.showToast('โต๊ะนี้ไม่ว่าง กรุณาเลือกโต๊ะอื่น', 'error');
                        return;
                    }

                    const confirmed = await Utils.confirm(`ยืนยันการเลือกโต๊ะ ${tableNumber}?`);
                    if (!confirmed) return;

                    Utils.showLoading();

                    try {
                        const response = await fetch('../api/tables.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                                action: 'start_session',
                                table_id: tableId
                            })
                        });

                        const result = await response.json();

                        if (result.success) {
                            Utils.showToast('เลือกโต๊ะสำเร็จ!', 'success');
                            setTimeout(() => {
                                window.location.href = `menu.php?table=${tableId}`;
                            }, 500);
                        } else {
                            Utils.showToast(result.message || 'เกิดข้อผิดพลาด', 'error');
                        }
                    } catch (error) {
                        console.error('Error:', error);
                        Utils.showToast('เกิดข้อผิดพลาดในการเชื่อมต่อ', 'error');
                    } finally {
                        Utils.hideLoading();
                    }
                });
            });

            // Handle card click (same as button click for available tables)
            document.querySelectorAll('.table-card.available').forEach(card => {
                card.addEventListener('click', (e) => {
                    if (!e.target.closest('.select-table-btn')) {
                        const btn = card.querySelector('.select-table-btn');
                        if (btn) btn.click();
                    }
                });
            });
        });
    </script>
</body>
</html>
