<?php
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
initSession();

// Check if table is selected from GET parameter or session
$tableId = isset($_GET['table']) ? (int)$_GET['table'] : ($_SESSION['table_id'] ?? null);

if (!$tableId) {
    redirect('select-table.php');
}

// Verify table exists and get table info
$db = getDB();
$stmt = $db->prepare("SELECT * FROM tables WHERE table_id = ?");
$stmt->execute([$tableId]);
$table = $stmt->fetch();

if (!$table) {
    redirect('select-table.php');
}

// Update session with current table
$_SESSION['table_id'] = $tableId;
$_SESSION['table_number'] = $table['table_number'];

// Get cart items with details
$db = getDB();
$cart = $_SESSION['cart'] ?? [];
$cartItems = [];
$total = 0;

if (!empty($cart)) {
    foreach ($cart as $index => $item) {
        $stmt = $db->prepare("
            SELECT m.*, c.name as category_name 
            FROM menu_items m 
            JOIN categories c ON m.category_id = c.category_id 
            WHERE m.menu_id = ?
        ");
        $stmt->execute([$item['menu_id']]);
        $menu = $stmt->fetch();
        
        if ($menu) {
            $subtotal = $menu['price'] * $item['quantity'];
            $total += $subtotal;
            
            $cartItems[] = [
                'index' => $index,
                'menu_id' => $item['menu_id'],
                'name_th' => $menu['name_th'],
                'category_name' => $menu['category_name'],
                'price' => $menu['price'],
                'quantity' => $item['quantity'],
                'special_request' => $item['special_request'] ?? '',
                'subtotal' => $subtotal,
                'image_url' => $menu['image_url']
            ];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ตะกร้าสินค้า - Akatsuki Restaurant</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .cart-item {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            box-shadow: var(--shadow);
            display: flex;
            gap: 1.5rem;
            align-items: center;
            transition: var(--transition);
        }
        
        .cart-item:hover {
            box-shadow: var(--shadow-hover);
        }
        
        .cart-item-image {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 8px;
            flex-shrink: 0;
        }
        
        .cart-item-details {
            flex: 1;
        }
        
        .cart-item-name {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 0.25rem;
        }
        
        .cart-item-category {
            color: var(--text-light);
            font-size: 0.9rem;
            margin-bottom: 0.5rem;
        }
        
        .cart-item-price {
            color: var(--primary-color);
            font-weight: 700;
            font-size: 1.1rem;
        }
        
        .cart-item-controls {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .quantity-control {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .quantity-btn {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            border: 2px solid var(--primary-color);
            background: white;
            color: var(--primary-color);
            font-size: 1.1rem;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .quantity-btn:hover {
            background: var(--primary-color);
            color: white;
        }
        
        .quantity-display {
            min-width: 40px;
            text-align: center;
            font-weight: 700;
            font-size: 1.1rem;
        }
        
        .remove-btn {
            color: var(--danger-color);
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            transition: var(--transition);
            padding: 0.5rem;
        }
        
        .remove-btn:hover {
            color: var(--primary-dark);
            transform: scale(1.2);
        }
        
        .summary-box {
            background: white;
            border-radius: 12px;
            padding: 2rem;
            box-shadow: var(--shadow);
            position: sticky;
            top: 100px;
        }
        
        .summary-row {
            display: flex;
            justify-content: space-between;
            padding: 0.75rem 0;
            border-bottom: 1px solid var(--border-color);
        }
        
        .summary-row:last-child {
            border-bottom: none;
            font-size: 1.3rem;
            font-weight: 700;
            color: var(--primary-color);
            padding-top: 1rem;
        }
        
        .empty-cart {
            text-align: center;
            padding: 4rem 2rem;
        }
        
        .empty-cart-icon {
            font-size: 5rem;
            color: var(--text-light);
            margin-bottom: 1rem;
        }
        
        .special-request-input {
            width: 100%;
            padding: 0.5rem;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            margin-top: 0.5rem;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <header class="header">
        <nav class="navbar">
            <div class="logo">
                <i class="fas fa-torii-gate logo-icon"></i>
                <span>Akatsuki Restaurant</span>
            </div>
            <ul class="nav-menu">
                <li><a href="../index.php" class="nav-link"><i class="fas fa-home"></i> หน้าแรก</a></li>
                <li><a href="menu.php?table=<?= $tableId ?>" class="nav-link"><i class="fas fa-book-open"></i> เมนู</a></li>
                <li><a href="cart.php" class="nav-link active"><i class="fas fa-shopping-cart"></i> ตะกร้า</a></li>
            </ul>
        </nav>
    </header>

    <section class="section">
        <div class="container">
            <h1 class="section-title">ตะกร้าสินค้า</h1>
            <p class="text-center text-muted mb-4">
                <i class="fas fa-chair"></i> โต๊ะ <?= e($table['table_number']) ?>
            </p>

            <?php if (empty($cartItems)): ?>
            <!-- Empty Cart -->
            <div class="empty-cart">
                <div class="empty-cart-icon">
                    <i class="fas fa-shopping-cart"></i>
                </div>
                <h2>ตะกร้าว่างเปล่า</h2>
                <p class="text-muted mb-4">คุณยังไม่ได้เพิ่มเมนูอาหารใดๆ</p>
                <a href="menu.php?table=<?= $tableId ?>" class="btn btn-primary btn-lg">
                    <i class="fas fa-book-open"></i> เลือกเมนูอาหาร
                </a>
            </div>
            <?php else: ?>
            <!-- Cart Items -->
            <div class="row">
                <div class="col col-8 col-sm-12">
                    <?php foreach ($cartItems as $item): ?>
                    <div class="cart-item" data-index="<?= $item['index'] ?>">
                        <img src="../assets/images/menu/<?= e($item['image_url']) ?>" 
                             alt="<?= e($item['name_th']) ?>" 
                             class="cart-item-image"
                             onerror="this.src='https://via.placeholder.com/100?text=<?= urlencode($item['name_th']) ?>'">
                        
                        <div class="cart-item-details">
                            <div class="cart-item-name"><?= e($item['name_th']) ?></div>
                            <div class="cart-item-category"><?= e($item['category_name']) ?></div>
                            <div class="cart-item-price"><?= formatCurrency($item['price']) ?> / ชิ้น</div>
                            
                            <?php if ($item['special_request']): ?>
                            <div style="margin-top: 0.5rem;">
                                <small class="text-muted">
                                    <i class="fas fa-comment"></i> <?= e($item['special_request']) ?>
                                </small>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="cart-item-controls">
                            <div class="quantity-control">
                                <button class="quantity-btn" onclick="updateQuantity(<?= $item['index'] ?>, -1)">
                                    <i class="fas fa-minus"></i>
                                </button>
                                <div class="quantity-display"><?= $item['quantity'] ?></div>
                                <button class="quantity-btn" onclick="updateQuantity(<?= $item['index'] ?>, 1)">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                            
                            <div style="text-align: center; min-width: 100px;">
                                <div style="font-size: 1.2rem; font-weight: 700; color: var(--primary-color);">
                                    <?= formatCurrency($item['subtotal']) ?>
                                </div>
                            </div>
                            
                            <button class="remove-btn" onclick="removeItem(<?= $item['index'] ?>)">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    
                    <div style="margin-top: 2rem;">
                        <a href="menu.php?table=<?= $tableId ?>" class="btn btn-outline">
                            <i class="fas fa-plus"></i> เพิ่มเมนูอื่น
                        </a>
                    </div>
                </div>
                
                <div class="col col-4 col-sm-12">
                    <div class="summary-box">
                        <h3 style="margin-bottom: 1.5rem;">สรุปรายการ</h3>
                        
                        <div class="summary-row">
                            <span>จำนวนรายการ</span>
                            <span><?= count($cartItems) ?> รายการ</span>
                        </div>
                        
                        <div class="summary-row">
                            <span>ยอดรวม</span>
                            <span><?= formatCurrency($total) ?></span>
                        </div>
                        
                        <button class="btn btn-success btn-block btn-lg mt-3" onclick="confirmOrder()">
                            <i class="fas fa-check"></i> ยืนยันออเดอร์
                        </button>
                        
                        <button class="btn btn-danger btn-block mt-2" onclick="clearCart()">
                            <i class="fas fa-trash"></i> ล้างตะกร้า
                        </button>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </section>

    <script src="../assets/js/main.js"></script>
    <script>
        // Update quantity
        async function updateQuantity(index, change) {
            Utils.showLoading();

            try {
                const response = await fetch('../api/cart.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'update',
                        index: index,
                        change: change
                    })
                });

                const result = await response.json();

                if (result.success) {
                    location.reload();
                } else {
                    Utils.showToast(result.message || 'เกิดข้อผิดพลาด', 'error');
                }
            } catch (error) {
                console.error('Error:', error);
                Utils.showToast('เกิดข้อผิดพลาด', 'error');
            } finally {
                Utils.hideLoading();
            }
        }

        // Remove item
        async function removeItem(index) {
            const confirmed = await Utils.confirm('ต้องการลบรายการนี้?');
            if (!confirmed) return;

            Utils.showLoading();

            try {
                const response = await fetch('../api/cart.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'remove',
                        index: index
                    })
                });

                const result = await response.json();

                if (result.success) {
                    Utils.showToast('ลบรายการสำเร็จ', 'success');
                    setTimeout(() => location.reload(), 500);
                } else {
                    Utils.showToast(result.message || 'เกิดข้อผิดพลาด', 'error');
                }
            } catch (error) {
                console.error('Error:', error);
                Utils.showToast('เกิดข้อผิดพลาด', 'error');
            } finally {
                Utils.hideLoading();
            }
        }

        // Clear cart
        async function clearCart() {
            const confirmed = await Utils.confirm('ต้องการล้างตะกร้าทั้งหมด?');
            if (!confirmed) return;

            Utils.showLoading();

            try {
                const response = await fetch('../api/cart.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'clear'
                    })
                });

                const result = await response.json();

                if (result.success) {
                    Utils.showToast('ล้างตะกร้าสำเร็จ', 'success');
                    setTimeout(() => location.reload(), 500);
                } else {
                    Utils.showToast(result.message || 'เกิดข้อผิดพลาด', 'error');
                }
            } catch (error) {
                console.error('Error:', error);
                Utils.showToast('เกิดข้อผิดพลาด', 'error');
            } finally {
                Utils.hideLoading();
            }
        }

        // Confirm order
        async function confirmOrder() {
            const confirmed = await Utils.confirm('ยืนยันการสั่งอาหาร?');
            if (!confirmed) return;

            Utils.showLoading();

            try {
                const response = await fetch('../api/orders.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'create_order'
                    })
                });

                const result = await response.json();

                if (result.success) {
                    Utils.showToast('สั่งอาหารสำเร็จ!', 'success');
                    setTimeout(() => {
                        window.location.href = 'order-status.php?order_id=' + result.order_id;
                    }, 1000);
                } else {
                    Utils.showToast(result.message || 'เกิดข้อผิดพลาด', 'error');
                }
            } catch (error) {
                console.error('Error:', error);
                Utils.showToast('เกิดข้อผิดพลาด', 'error');
            } finally {
                Utils.hideLoading();
            }
        }
    </script>
</body>
</html>
