<?php
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
initSession();

// Check if table is selected
if (!isset($_GET['table']) || empty($_GET['table'])) {
    redirect('customer/select-table.php');
}

$tableId = (int)$_GET['table'];

// Get table info
$db = getDB();
$stmt = $db->prepare("SELECT * FROM tables WHERE table_id = ?");
$stmt->execute([$tableId]);
$table = $stmt->fetch();

if (!$table) {
    redirect('customer/select-table.php');
}

// Save table to session
$_SESSION['table_id'] = $tableId;
$_SESSION['table_number'] = $table['table_number'];

// Get all categories
$stmt = $db->query("SELECT * FROM categories ORDER BY display_order, category_id");
$categories = $stmt->fetchAll();

// Get all menu items
$stmt = $db->query("
    SELECT m.*, c.name as category_name 
    FROM menu_items m 
    JOIN categories c ON m.category_id = c.category_id 
    WHERE m.is_available = 1 
    ORDER BY c.display_order, m.popularity_score DESC
");
$menuItems = $stmt->fetchAll();

// Group menu items by category
$menuByCategory = [];
foreach ($menuItems as $item) {
    $menuByCategory[$item['category_id']][] = $item;
}

// Get cart count
$cartCount = 0;
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $cartCount += $item['quantity'];
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เมนูอาหาร - Akatsuki Restaurant</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .category-tabs {
            display: flex;
            gap: 0.5rem;
            overflow-x: auto;
            padding: 1rem 0;
            margin-bottom: 2rem;
            border-bottom: 2px solid var(--border-color);
        }
        
        .category-tab {
            padding: 0.75rem 1.5rem;
            border: 2px solid var(--border-color);
            border-radius: 25px;
            background: white;
            cursor: pointer;
            transition: var(--transition);
            white-space: nowrap;
            font-weight: 500;
        }
        
        .category-tab:hover {
            border-color: var(--primary-color);
            color: var(--primary-color);
        }
        
        .category-tab.active {
            background: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
        }
        
        .menu-item-card {
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        
        .menu-item-card .card-body {
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        
        .menu-item-card .card-text {
            flex: 1;
        }
        
        .quantity-control {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-top: 1rem;
        }
        
        .quantity-btn {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            border: 2px solid var(--primary-color);
            background: white;
            color: var(--primary-color);
            font-size: 1.2rem;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .quantity-btn:hover {
            background: var(--primary-color);
            color: white;
        }
        
        .quantity-input {
            width: 60px;
            text-align: center;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            padding: 0.5rem;
            font-weight: 600;
        }
        
        .cart-float {
            position: fixed;
            bottom: 2rem;
            right: 2rem;
            z-index: 1000;
        }
        
        .cart-btn {
            position: relative;
            width: 70px;
            height: 70px;
            border-radius: 50%;
            background: var(--primary-color);
            color: white;
            border: none;
            box-shadow: 0 4px 20px rgba(230, 0, 18, 0.4);
            cursor: pointer;
            transition: var(--transition);
            font-size: 1.8rem;
        }
        
        .cart-btn:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 30px rgba(230, 0, 18, 0.6);
        }
        
        .cart-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--secondary-color);
            color: var(--text-dark);
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 0.9rem;
            border: 3px solid white;
        }
        
        .table-info {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            color: white;
            padding: 1.5rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .search-box {
            margin-bottom: 2rem;
        }
        
        .search-input {
            width: 100%;
            padding: 1rem 1.5rem;
            border: 2px solid var(--border-color);
            border-radius: 25px;
            font-size: 1rem;
            transition: var(--transition);
        }
        
        .search-input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(230, 0, 18, 0.1);
        }
    </style>
</head>
<body>
    <header class="header">
        <nav class="navbar">
            <div class="logo">
                <i class="fas fa-torii-gate logo-icon"></i>
                <span>Akatsuki Restaurant</span>
            </div>
            <ul class="nav-menu">
                <li><a href="../index.php" class="nav-link"><i class="fas fa-home"></i> หน้าแรก</a></li>
                <li><a href="menu.php?table=<?= $tableId ?>" class="nav-link active"><i class="fas fa-book-open"></i> เมนู</a></li>
                <li><a href="cart.php?table=<?= $tableId ?>" class="nav-link"><i class="fas fa-shopping-cart"></i> ตะกร้า (<?= $cartCount ?>)</a></li>
            </ul>
        </nav>
    </header>

    <section class="section">
        <div class="container">
            <!-- Table Info -->
            <div class="table-info">
                <div>
                    <h2 style="color: white; margin-bottom: 0.5rem;">
                        <i class="fas fa-chair"></i> โต๊ะ <?= e($table['table_number']) ?>
                    </h2>
                    <p style="margin: 0; opacity: 0.9;">
                        <i class="fas fa-users"></i> <?= $table['seats'] ?> ที่นั่ง
                    </p>
                </div>
                <div>
                    <a href="select-table.php" class="btn btn-secondary">
                        <i class="fas fa-exchange-alt"></i> เปลี่ยนโต๊ะ
                    </a>
                </div>
            </div>

            <!-- Search Box -->
            <div class="search-box">
                <input type="text" 
                       class="search-input" 
                       id="searchInput" 
                       placeholder="🔍 ค้นหาเมนูอาหาร...">
            </div>

            <!-- Category Tabs -->
            <div class="category-tabs" id="categoryTabs">
                <button class="category-tab active" data-category="all">
                    <i class="fas fa-th"></i> ทั้งหมด
                </button>
                <?php foreach ($categories as $category): ?>
                <button class="category-tab" data-category="<?= $category['category_id'] ?>">
                    <?= e($category['name']) ?>
                </button>
                <?php endforeach; ?>
            </div>

            <!-- Menu Items -->
            <div id="menuContainer">
                <?php foreach ($categories as $category): ?>
                    <?php if (isset($menuByCategory[$category['category_id']])): ?>
                    <div class="category-section" data-category-id="<?= $category['category_id'] ?>">
                        <h2 class="section-title" style="text-align: left;">
                            <?= e($category['name']) ?>
                        </h2>
                        <div class="row">
                            <?php foreach ($menuByCategory[$category['category_id']] as $item): ?>
                            <div class="col col-3 col-sm-6 menu-item" 
                                 data-category="<?= $item['category_id'] ?>"
                                 data-name="<?= e(strtolower($item['name_th'])) ?>"
                                 style="margin-bottom: 2rem;">
                                <div class="card menu-item-card">
                                    <img src="../assets/images/menu/<?= e($item['image_url']) ?>" 
                                         alt="<?= e($item['name_th']) ?>" 
                                         class="card-img"
                                         onerror="this.src='https://via.placeholder.com/300x200?text=<?= urlencode($item['name_th']) ?>'">
                                    <div class="card-body">
                                        <div class="card-subtitle"><?= e($item['category_name']) ?></div>
                                        <h3 class="card-title"><?= e($item['name_th']) ?></h3>
                                        <?php if ($item['description']): ?>
                                        <p class="card-text"><?= e($item['description']) ?></p>
                                        <?php endif; ?>
                                        <div class="card-price"><?= formatCurrency($item['price']) ?></div>
                                        
                                        <div class="quantity-control">
                                            <button class="quantity-btn" onclick="decreaseQty(this)">
                                                <i class="fas fa-minus"></i>
                                            </button>
                                            <input type="number" class="quantity-input" value="1" min="1" max="99">
                                            <button class="quantity-btn" onclick="increaseQty(this)">
                                                <i class="fas fa-plus"></i>
                                            </button>
                                        </div>
                                        
                                        <button class="btn btn-primary btn-block mt-3" 
                                                onclick="addToCart(<?= $item['menu_id'] ?>, this)">
                                            <i class="fas fa-cart-plus"></i> เพิ่มลงตะกร้า
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>

            <!-- No Results Message -->
            <div id="noResults" style="display: none;" class="text-center">
                <div class="alert alert-info">
                    <i class="fas fa-search"></i> ไม่พบเมนูที่ค้นหา
                </div>
            </div>
        </div>
    </section>

    <!-- Floating Cart Button -->
    <div class="cart-float">
        <button class="cart-btn" onclick="window.location.href='cart.php?table=<?= $tableId ?>'">
            <i class="fas fa-shopping-cart"></i>
            <?php if ($cartCount > 0): ?>
            <span class="cart-badge"><?= $cartCount ?></span>
            <?php endif; ?>
        </button>
    </div>

    <script src="../assets/js/main.js"></script>
    <script>
        // Quantity controls
        function increaseQty(btn) {
            const input = btn.parentElement.querySelector('.quantity-input');
            const currentVal = parseInt(input.value) || 1;
            if (currentVal < 99) {
                input.value = currentVal + 1;
            }
        }

        function decreaseQty(btn) {
            const input = btn.parentElement.querySelector('.quantity-input');
            const currentVal = parseInt(input.value) || 1;
            if (currentVal > 1) {
                input.value = currentVal - 1;
            }
        }

        // Add to cart
        async function addToCart(menuId, btn) {
            const card = btn.closest('.card');
            const quantityInput = card.querySelector('.quantity-input');
            const quantity = parseInt(quantityInput.value) || 1;

            Utils.showLoading();

            try {
                const response = await fetch('../api/cart.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'add',
                        menu_id: menuId,
                        quantity: quantity
                    })
                });

                const result = await response.json();

                if (result.success) {
                    Utils.showToast('เพิ่มลงตะกร้าสำเร็จ!', 'success');
                    quantityInput.value = 1; // Reset quantity
                    
                    // Update cart badge
                    setTimeout(() => {
                        location.reload();
                    }, 500);
                } else {
                    Utils.showToast(result.message || 'เกิดข้อผิดพลาด', 'error');
                }
            } catch (error) {
                console.error('Error:', error);
                Utils.showToast('เกิดข้อผิดพลาด', 'error');
            } finally {
                Utils.hideLoading();
            }
        }

        // Category filter
        document.querySelectorAll('.category-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                // Update active tab
                document.querySelectorAll('.category-tab').forEach(t => t.classList.remove('active'));
                tab.classList.add('active');

                const category = tab.dataset.category;
                filterMenu(category);
            });
        });

        function filterMenu(category) {
            const sections = document.querySelectorAll('.category-section');
            
            if (category === 'all') {
                sections.forEach(section => section.style.display = 'block');
            } else {
                sections.forEach(section => {
                    if (section.dataset.categoryId === category) {
                        section.style.display = 'block';
                    } else {
                        section.style.display = 'none';
                    }
                });
            }

            checkNoResults();
        }

        // Search functionality
        const searchInput = document.getElementById('searchInput');
        searchInput.addEventListener('input', Utils.debounce((e) => {
            const searchTerm = e.target.value.toLowerCase().trim();
            const menuItems = document.querySelectorAll('.menu-item');

            if (searchTerm === '') {
                // Show all items
                menuItems.forEach(item => item.style.display = 'block');
                document.querySelectorAll('.category-section').forEach(section => {
                    section.style.display = 'block';
                });
            } else {
                // Filter items
                menuItems.forEach(item => {
                    const name = item.dataset.name;
                    if (name.includes(searchTerm)) {
                        item.style.display = 'block';
                    } else {
                        item.style.display = 'none';
                    }
                });

                // Hide empty sections
                document.querySelectorAll('.category-section').forEach(section => {
                    const visibleItems = section.querySelectorAll('.menu-item[style*="display: block"], .menu-item:not([style*="display: none"])');
                    if (visibleItems.length === 0) {
                        section.style.display = 'none';
                    } else {
                        section.style.display = 'block';
                    }
                });
            }

            checkNoResults();
        }, 300));

        function checkNoResults() {
            const visibleItems = document.querySelectorAll('.menu-item:not([style*="display: none"])');
            const noResults = document.getElementById('noResults');
            
            if (visibleItems.length === 0) {
                noResults.style.display = 'block';
            } else {
                noResults.style.display = 'none';
            }
        }
    </script>
</body>
</html>
